import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Building2, 
  FileText, 
  Mail, 
  Users, 
  BarChart3, 
  Zap, 
  Settings,
  TrendingUp,
  TrendingDown,
  Activity,
  Clock
} from 'lucide-react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const Dashboard: React.FC = () => {
  // Real data counts
  const [stats, setStats] = useState({
    exhibitions: 3, // İstanbul Yapı, Ankara Teknoloji, İzmir Gıda
    companies: 3, // ABC İnşaat, XYZ Teknoloji, DEF Gıda
    quotations: 3, // Stand Projesi, Hostes Catering, Şirket Tanıtımı
    emailTemplates: 10, // Mail şablonları sayısı
    personnel: 3, // Furkan, Ayşe, Mehmet
    automation: 6,
    settings: 1
  });

  const [recentActivities, setRecentActivities] = useState([
    { id: 1, user: 'Furkan Bedir', action: 'Stand projesi teklifi gönderdi', company: 'ABC İnşaat Ltd. Şti.', time: '2 dakika önce', type: 'quotation' },
    { id: 2, user: 'Ayşe Yılmaz', action: 'Firma durumunu güncelledi', company: 'XYZ Teknoloji A.Ş.', time: '15 dakika önce', type: 'company' },
    { id: 3, user: 'Mehmet Kaya', action: 'Yeni fuar ekledi', company: 'İzmir Gıda Fuarı 2024', time: '1 saat önce', type: 'exhibition' },
    { id: 4, user: 'Furkan Bedir', action: 'Mail şablonu oluşturdu', company: 'Hostes Teklifi', time: '2 saat önce', type: 'template' },
    { id: 5, user: 'Ayşe Yılmaz', action: 'Personel bilgilerini güncelledi', company: 'Sistem Ayarları', time: '3 saat önce', type: 'personnel' }
  ]);

  const monthlyData = [
    { month: 'Ocak', teklifler: 8, firmalar: 12 },
    { month: 'Şubat', teklifler: 12, firmalar: 18 },
    { month: 'Mart', teklifler: 15, firmalar: 22 },
    { month: 'Nisan', teklifler: 18, firmalar: 28 },
    { month: 'Mayıs', teklifler: 22, firmalar: 35 },
    { month: 'Haziran', teklifler: 25, firmalar: 42 }
  ];

  const quotationStatusData = [
    { name: 'Taslak', value: 1, color: '#6B7280' },
    { name: 'Gönderildi', value: 1, color: '#3B82F6' },
    { name: 'Onaylandı', value: 1, color: '#10B981' },
    { name: 'Değerlendiriliyor', value: 0, color: '#8B5CF6' }
  ];

  const dashboardCards = [
    {
      title: 'Fuarlar',
      count: stats.exhibitions,
      icon: Calendar,
      color: 'bg-blue-500',
      href: '/exhibitions'
    },
    {
      title: 'Firmalar',
      count: stats.companies,
      icon: Building2,
      color: 'bg-green-500',
      href: '/companies'
    },
    {
      title: 'Teklifler',
      count: stats.quotations,
      icon: FileText,
      color: 'bg-orange-500',
      href: '/quotations'
    },
    {
      title: 'Mail Şablonları',
      count: stats.emailTemplates,
      icon: Mail,
      color: 'bg-purple-500',
      href: '/email-templates'
    },
    {
      title: 'Personeller',
      count: stats.personnel,
      icon: Users,
      color: 'bg-teal-500',
      href: '/personnel'
    },
    {
      title: 'Otomasyon',
      count: stats.automation,
      icon: Zap,
      color: 'bg-yellow-500',
      href: '/automation'
    },
    {
      title: 'Ayarlar',
      count: stats.settings,
      icon: Settings,
      color: 'bg-gray-500',
      href: '/settings'
    }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'quotation': return <FileText className="w-4 h-4" />;
      case 'company': return <Building2 className="w-4 h-4" />;
      case 'exhibition': return <Calendar className="w-4 h-4" />;
      case 'template': return <Mail className="w-4 h-4" />;
      case 'personnel': return <Users className="w-4 h-4" />;
      default: return <Activity className="w-4 h-4" />;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'quotation': return 'bg-orange-100 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400';
      case 'company': return 'bg-green-100 text-green-600 dark:bg-green-900/20 dark:text-green-400';
      case 'exhibition': return 'bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400';
      case 'template': return 'bg-purple-100 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400';
      case 'personnel': return 'bg-teal-100 text-teal-600 dark:bg-teal-900/20 dark:text-teal-400';
      default: return 'bg-gray-100 text-gray-600 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Melin Fuarcılık ve Organizasyon Yönetim Sistemi
          </p>
        </div>
        <div className="flex items-center space-x-2 text-green-600 dark:text-green-400">
          <TrendingUp className="w-5 h-5" />
          <span className="text-lg font-medium">Sistem Aktif</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {dashboardCards.map((card, index) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer group"
          >
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{card.count}</p>
                </div>
                <div className={`p-3 rounded-full ${card.color} group-hover:scale-110 transition-transform duration-200`}>
                  <card.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center space-x-1">
                  <Activity className="w-4 h-4 text-blue-500" />
                  <span className="text-sm font-medium text-blue-600 dark:text-blue-400">Aktif</span>
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">Güncel</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Performance */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Aylık Performans
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="teklifler" fill="#3B82F6" name="Teklifler" />
              <Bar dataKey="firmalar" fill="#10B981" name="Firmalar" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Quotation Status */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
        >
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Teklif Durumları
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={quotationStatusData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {quotationStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-2 gap-4">
            {quotationStatusData.map((item, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm text-gray-600 dark:text-gray-400">{item.name}</span>
                <span className="text-sm font-medium text-gray-900 dark:text-white">{item.value}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Recent Activities */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Son Aktiviteler
          </h3>
          <button className="text-sm text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300">
            Tümünü Gör
          </button>
        </div>
        <div className="space-y-4">
          {recentActivities.map((activity, index) => (
            <motion.div
              key={activity.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              <div className={`p-2 rounded-full ${getActivityColor(activity.type)}`}>
                {getActivityIcon(activity.type)}
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-900 dark:text-white">
                  <span className="font-medium">{activity.user}</span> {activity.action}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{activity.company}</p>
              </div>
              <div className="flex items-center space-x-1 text-gray-400">
                <Clock className="w-4 h-4" />
                <span className="text-xs">{activity.time}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
import React, { useState, useRef, useEffect } from 'react';
import { 
  Bold, 
  Italic, 
  Underline, 
  AlignLeft, 
  AlignCenter, 
  AlignRight,
  List,
  ListOrdered,
  Link,
  Image,
  Type,
  Palette,
  FileSignature
} from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  showSignatureOption?: boolean;
  onAddSignature?: () => void;
}

const RichTextEditor: React.FC<RichTextEditorProps> = ({ 
  value, 
  onChange, 
  placeholder = "İçeriğinizi yazın...",
  showSignatureOption = false,
  onAddSignature
}) => {
  const editorRef = useRef<HTMLDivElement>(null);
  const [selectedFontSize, setSelectedFontSize] = useState('14');
  const [selectedFontFamily, setSelectedFontFamily] = useState('Arial');

  const fontSizes = ['10', '12', '14', '16', '18', '20', '24', '28', '32'];
  const fontFamilies = ['Arial', 'Times New Roman', 'Helvetica', 'Georgia', 'Verdana', 'Tahoma'];

  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value;
    }
  }, [value]);

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const handleFontSize = (size: string) => {
    setSelectedFontSize(size);
    execCommand('fontSize', '3');
    // Custom font size implementation
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const span = document.createElement('span');
      span.style.fontSize = size + 'px';
      try {
        range.surroundContents(span);
      } catch (e) {
        span.appendChild(range.extractContents());
        range.insertNode(span);
      }
      if (editorRef.current) {
        onChange(editorRef.current.innerHTML);
      }
    }
  };

  const handleFontFamily = (family: string) => {
    setSelectedFontFamily(family);
    execCommand('fontName', family);
  };

  const insertLink = () => {
    const url = prompt('Link URL girin:');
    if (url) {
      execCommand('createLink', url);
    }
  };

  const insertImage = () => {
    const url = prompt('Resim URL girin:');
    if (url) {
      execCommand('insertImage', url);
    }
  };

  const changeTextColor = () => {
    const color = prompt('Renk kodu girin (örn: #ff0000):');
    if (color) {
      execCommand('foreColor', color);
    }
  };

  return (
    <div className="border border-gray-300 dark:border-gray-600 rounded-lg overflow-hidden">
      {/* Toolbar */}
      <div className="bg-gray-50 dark:bg-gray-700 border-b border-gray-300 dark:border-gray-600 p-2">
        <div className="flex flex-wrap items-center gap-2">
          {/* Font Family */}
          <select
            value={selectedFontFamily}
            onChange={(e) => handleFontFamily(e.target.value)}
            className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-800 dark:text-white"
          >
            {fontFamilies.map(font => (
              <option key={font} value={font}>{font}</option>
            ))}
          </select>

          {/* Font Size */}
          <select
            value={selectedFontSize}
            onChange={(e) => handleFontSize(e.target.value)}
            className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-800 dark:text-white"
          >
            {fontSizes.map(size => (
              <option key={size} value={size}>{size}px</option>
            ))}
          </select>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600" />

          {/* Text Formatting */}
          <button
            type="button"
            onClick={() => execCommand('bold')}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Kalın"
          >
            <Bold className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => execCommand('italic')}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="İtalik"
          >
            <Italic className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => execCommand('underline')}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Altı Çizili"
          >
            <Underline className="w-4 h-4" />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600" />

          {/* Text Color */}
          <button
            type="button"
            onClick={changeTextColor}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Yazı Rengi"
          >
            <Palette className="w-4 h-4" />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600" />

          {/* Alignment */}
          <button
            type="button"
            onClick={() => execCommand('justifyLeft')}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Sola Hizala"
          >
            <AlignLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => execCommand('justifyCenter')}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Ortala"
          >
            <AlignCenter className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => execCommand('justifyRight')}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Sağa Hizala"
          >
            <AlignRight className="w-4 h-4" />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600" />

          {/* Lists */}
          <button
            type="button"
            onClick={() => execCommand('insertUnorderedList')}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Madde İşareti"
          >
            <List className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => execCommand('insertOrderedList')}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Numaralı Liste"
          >
            <ListOrdered className="w-4 h-4" />
          </button>

          <div className="w-px h-6 bg-gray-300 dark:bg-gray-600" />

          {/* Link & Image */}
          <button
            type="button"
            onClick={insertLink}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Link Ekle"
          >
            <Link className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={insertImage}
            className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded"
            title="Resim Ekle"
          >
            <Image className="w-4 h-4" />
          </button>

          {/* Signature Option */}
          {showSignatureOption && onAddSignature && (
            <>
              <div className="w-px h-6 bg-gray-300 dark:bg-gray-600" />
              <button
                type="button"
                onClick={onAddSignature}
                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded text-blue-600 dark:text-blue-400"
                title="İmza Ekle"
              >
                <FileSignature className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Editor */}
      <div
        ref={editorRef}
        contentEditable
        onInput={handleInput}
        className="min-h-[200px] p-4 focus:outline-none dark:bg-gray-800 dark:text-white"
        style={{ minHeight: '200px' }}
        dangerouslySetInnerHTML={{ __html: value }}
        data-placeholder={placeholder}
      />

      <style jsx>{`
        [contenteditable]:empty:before {
          content: attr(data-placeholder);
          color: #9ca3af;
          pointer-events: none;
        }
      `}</style>
    </div>
  );
};

export default RichTextEditor;
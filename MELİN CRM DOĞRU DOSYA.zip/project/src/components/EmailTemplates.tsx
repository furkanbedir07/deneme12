import React, { useState, useEffect } from 'react';
import { 
  Mail, 
  MessageSquare,
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  Eye,
  Copy,
  X,
  Save,
  FileText,
  Settings,
  Code,
  Type,
  Smartphone
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  type: 'email' | 'whatsapp';
  category: string;
  variables: string[];
  created_at: string;
  updated_at: string;
}

interface TemplateCategory {
  id: string;
  name: string;
  color: string;
  description?: string;
}

const EmailTemplates: React.FC = () => {
  const [templates, setTemplates] = useState<EmailTemplate[]>([
    {
      id: '1',
      name: 'Stand Projesi Teklifi',
      subject: 'Stand Projesi Teklifimiz - {company_name}',
      content: `Sayın {contact_person},

{exhibition_name} fuarı için hazırladığımız stand projesi teklifimizi ekte bulabilirsiniz.

Teklif Detayları:
- Stand Alanı: {stand_area} m²
- Proje Türü: Özel Tasarım
- Teslim Süresi: {delivery_time} gün

Teklifimiz {valid_until} tarihine kadar geçerlidir.

Detaylı bilgi ve görüşme için bizimle iletişime geçebilirsiniz.

Saygılarımızla,
Melin Fuarcılık ve Organizasyon
Tel: +90 212 555 0000
E-posta: info@melinfuar.com`,
      type: 'email',
      category: 'Teklif',
      variables: ['company_name', 'contact_person', 'exhibition_name', 'stand_area', 'delivery_time', 'valid_until'],
      created_at: '2024-01-15T10:30:00Z',
      updated_at: '2024-01-20T14:45:00Z'
    },
    {
      id: '2',
      name: 'Hostes ve Catering Teklifi',
      subject: 'Hostes ve Catering Hizmeti Teklifimiz - {company_name}',
      content: `Merhaba {contact_person},

{exhibition_name} fuarı için talep ettiğiniz hostes ve catering hizmeti teklifimizi hazırladık.

Hizmet Detayları:
- Hostes Sayısı: {hostess_count} kişi
- Hizmet Süresi: {service_days} gün
- Catering Türü: {catering_type}

Teklifimiz {valid_until} tarihine kadar geçerlidir.

Detaylar için ekteki dosyayı inceleyebilirsiniz.

İyi günler,
Melin Fuarcılık Ekibi`,
      type: 'email',
      category: 'Teklif',
      variables: ['company_name', 'contact_person', 'exhibition_name', 'hostess_count', 'service_days', 'catering_type', 'valid_until'],
      created_at: '2024-01-12T09:15:00Z',
      updated_at: '2024-01-18T16:20:00Z'
    },
    {
      id: '3',
      name: 'Melin Dizayn Şirket Tanıtım Paketi',
      subject: 'Melin Dizayn Şirket Tanıtım Hizmetleri - {company_name}',
      content: `Sayın {contact_person},

{company_name} için hazırladığımız Melin Dizayn şirket tanıtım paketi teklifimizi sunuyoruz.

Paket İçeriği:
- Katalog Tasarımı ve Baskı
- Broşür Hazırlığı
- Dijital Tanıtım Materyalleri
- Fuar Standı Grafik Tasarımları
- Logo ve Kurumsal Kimlik Çalışmaları

Bu paket ile {exhibition_name} fuarında firmanızı en iyi şekilde tanıtabilirsiniz.

Teklifimiz hakkında görüşmek için bizi arayabilirsiniz.

Başarılar dileriz,
Melin Fuarcılık`,
      type: 'email',
      category: 'Tanıtım',
      variables: ['company_name', 'contact_person', 'exhibition_name'],
      created_at: '2024-01-08T11:45:00Z',
      updated_at: '2024-01-16T13:30:00Z'
    },
    {
      id: '4',
      name: 'WhatsApp Teklif Bildirimi',
      subject: '',
      content: 'Merhaba {contact_person}, yapmış olduğumuz görüşmeye istinaden sizlere {exhibition_name} fuarı için teklifimizi mail olarak gönderdim. Buradan da sizlere bilgi vermek istedim. Sormanız veya yardıma ihtiyacınız olan herhangi bir durum olursa WhatsApp hattımızdan da bize ulaşabilirsiniz. 🙏\n\nMelin Fuarcılık\n📞 +90 212 555 0000',
      type: 'whatsapp',
      category: 'Bildirim',
      variables: ['contact_person', 'exhibition_name'],
      created_at: '2024-01-10T15:20:00Z',
      updated_at: '2024-01-10T15:20:00Z'
    },
    {
      id: '5',
      name: 'WhatsApp Takip Mesajı',
      subject: '',
      content: 'Sayın {contact_person}, {exhibition_name} için gönderdiğimiz teklif hakkında düşüncelerinizi öğrenebilir miyiz? Herhangi bir sorunuz varsa bizimle iletişime geçebilirsiniz. 😊\n\nMelin Fuarcılık\n📞 +90 212 555 0000',
      type: 'whatsapp',
      category: 'Takip',
      variables: ['contact_person', 'exhibition_name'],
      created_at: '2024-01-14T12:10:00Z',
      updated_at: '2024-01-14T12:10:00Z'
    },
    {
      id: '6',
      name: 'Fuar Hatırlatma E-postası',
      subject: '{exhibition_name} Fuarı Yaklaşıyor!',
      content: `Sayın {contact_person},

{exhibition_name} fuarına sadece {days_left} gün kaldı!

Son hazırlıklarınız için size yardımcı olmaya hazırız:
- Stand kurulum desteği
- Son dakika malzeme ihtiyaçları
- Fuar günü koordinasyon

Herhangi bir ihtiyacınız olursa bizimle iletişime geçin.

Başarılı bir fuar dileriz!
Melin Fuarcılık`,
      type: 'email',
      category: 'Hatırlatma',
      variables: ['contact_person', 'exhibition_name', 'days_left'],
      created_at: '2024-01-20T09:30:00Z',
      updated_at: '2024-01-20T09:30:00Z'
    },
    {
      id: '7',
      name: 'Teşekkür E-postası',
      subject: 'Teşekkürler - {company_name}',
      content: `Sayın {contact_person},

{exhibition_name} fuarında bizimle çalıştığınız için teşekkür ederiz.

İş birliğimizden çok memnun kaldık ve gelecekteki projelerinizde de sizinle çalışmayı dört gözle bekliyoruz.

Referanslarınız için her zaman hazırız.

Saygılarımızla,
Melin Fuarcılık`,
      type: 'email',
      category: 'Teşekkür',
      variables: ['contact_person', 'company_name', 'exhibition_name'],
      created_at: '2024-01-22T16:45:00Z',
      updated_at: '2024-01-22T16:45:00Z'
    },
    {
      id: '8',
      name: 'İlk İletişim E-postası',
      subject: 'Melin Fuarcılık - {exhibition_name} Katılımınız',
      content: `Sayın {contact_person},

{exhibition_name} fuarına katılım göstereceğinizi öğrendik.

Melin Fuarcılık olarak size aşağıdaki hizmetlerimizi sunabiliriz:
- Stand tasarımı ve uygulaması
- Hostes ve catering hizmetleri
- Tanıtım materyalleri hazırlığı

Detaylı bilgi almak için bizimle iletişime geçebilirsiniz.

İyi günler,
Melin Fuarcılık`,
      type: 'email',
      category: 'Bildirim',
      variables: ['contact_person', 'exhibition_name'],
      created_at: '2024-01-25T11:20:00Z',
      updated_at: '2024-01-25T11:20:00Z'
    },
    {
      id: '9',
      name: 'WhatsApp Anlaşma Onayı',
      subject: '',
      content: 'Merhaba {contact_person}, {exhibition_name} için anlaşmamızı onayladığınız için teşekkür ederiz! 🎉 Sözleşme detaylarını mail olarak gönderdik. Başarılı bir fuar dileriz! 💪\n\nMelin Fuarcılık\n📞 +90 212 555 0000',
      type: 'whatsapp',
      category: 'Teşekkür',
      variables: ['contact_person', 'exhibition_name'],
      created_at: '2024-01-26T14:30:00Z',
      updated_at: '2024-01-26T14:30:00Z'
    },
    {
      id: '10',
      name: 'Fuar Sonrası Değerlendirme',
      subject: 'Fuar Değerlendirmesi - {exhibition_name}',
      content: `Sayın {contact_person},

{exhibition_name} fuarının başarıyla tamamlanması için gösterdiğiniz iş birliğinden dolayı teşekkür ederiz.

Fuar sürecini değerlendirmek ve gelecekteki projelerimizi daha iyi planlayabilmek için görüşlerinizi almak istiyoruz.

Uygun olduğunuz bir zamanda kısa bir değerlendirme toplantısı yapabilir miyiz?

Saygılarımızla,
Melin Fuarcılık`,
      type: 'email',
      category: 'Takip',
      variables: ['contact_person', 'exhibition_name'],
      created_at: '2024-01-28T10:15:00Z',
      updated_at: '2024-01-28T10:15:00Z'
    }
  ]);

  const [categories, setCategories] = useState<TemplateCategory[]>([
    { id: '1', name: 'Teklif', color: '#3B82F6', description: 'Teklif gönderimi şablonları' },
    { id: '2', name: 'Takip', color: '#10B981', description: 'Müşteri takip mesajları' },
    { id: '3', name: 'Bildirim', color: '#F59E0B', description: 'Genel bildirim mesajları' },
    { id: '4', name: 'Hatırlatma', color: '#8B5CF6', description: 'Hatırlatma mesajları' },
    { id: '5', name: 'Tanıtım', color: '#EF4444', description: 'Tanıtım ve pazarlama' },
    { id: '6', name: 'Teşekkür', color: '#06B6D4', description: 'Teşekkür mesajları' }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate | null>(null);
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);

  const [newTemplate, setNewTemplate] = useState({
    name: '',
    subject: '',
    content: '',
    type: 'email' as const,
    category: 'Teklif'
  });

  const templateTypes = [
    { value: 'email', label: 'E-posta', icon: Mail, color: 'text-blue-600' },
    { value: 'whatsapp', label: 'WhatsApp', icon: MessageSquare, color: 'text-green-600' }
  ];

  const commonVariables = [
    'company_name', 'contact_person', 'exhibition_name', 'phone', 'email',
    'stand_area', 'delivery_time', 'valid_until', 'hostess_count', 'service_days', 
    'catering_type', 'days_left', 'project_type', 'total_amount', 'currency'
  ];

  const getCategoryColor = (category: string) => {
    const categoryObj = categories.find(c => c.name === category);
    if (!categoryObj) return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    
    const colorMap: { [key: string]: string } = {
      '#3B82F6': 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400',
      '#10B981': 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400',
      '#F59E0B': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400',
      '#8B5CF6': 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400',
      '#EF4444': 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400',
      '#06B6D4': 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/20 dark:text-cyan-400'
    };
    
    return colorMap[categoryObj.color] || 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
  };

  const extractVariables = (content: string): string[] => {
    const matches = content.match(/\{([^}]+)\}/g);
    return matches ? matches.map(match => match.slice(1, -1)) : [];
  };

  const handleAddTemplate = () => {
    if (!newTemplate.name || !newTemplate.content) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    if (newTemplate.type === 'email' && !newTemplate.subject) {
      toast.error('E-posta şablonları için konu zorunludur');
      return;
    }

    const variables = extractVariables(newTemplate.content + ' ' + newTemplate.subject);
    const template: EmailTemplate = {
      id: Date.now().toString(),
      ...newTemplate,
      variables: [...new Set(variables)],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    setTemplates([...templates, template]);
    setNewTemplate({
      name: '',
      subject: '',
      content: '',
      type: 'email',
      category: 'Teklif'
    });
    setShowAddModal(false);
    toast.success('Şablon başarıyla eklendi');
  };

  const handleEditTemplate = () => {
    if (!editingTemplate) return;

    const variables = extractVariables(editingTemplate.content + ' ' + editingTemplate.subject);
    const updatedTemplate = {
      ...editingTemplate,
      variables: [...new Set(variables)],
      updated_at: new Date().toISOString()
    };

    setTemplates(templates.map(template => 
      template.id === editingTemplate.id ? updatedTemplate : template
    ));
    setShowEditModal(false);
    setEditingTemplate(null);
    toast.success('Şablon başarıyla güncellendi');
  };

  const handleDeleteTemplate = (id: string) => {
    if (window.confirm('Bu şablonu silmek istediğinizden emin misiniz?')) {
      setTemplates(templates.filter(template => template.id !== id));
      toast.success('Şablon başarıyla silindi');
    }
  };

  const handleViewTemplate = (template: EmailTemplate) => {
    setSelectedTemplate(template);
    setShowDetailModal(true);
  };

  const handleEditClick = (template: EmailTemplate) => {
    setEditingTemplate({ ...template });
    setShowEditModal(true);
  };

  const handleCopyTemplate = (template: EmailTemplate) => {
    navigator.clipboard.writeText(template.content);
    toast.success('Şablon içeriği kopyalandı');
  };

  const insertVariable = (variable: string, isEditing: boolean = false) => {
    const variableText = `{${variable}}`;
    if (isEditing && editingTemplate) {
      setEditingTemplate({
        ...editingTemplate,
        content: editingTemplate.content + variableText
      });
    } else {
      setNewTemplate({
        ...newTemplate,
        content: newTemplate.content + variableText
      });
    }
  };

  const addCategory = (name: string, color: string, description: string) => {
    const newCategory: TemplateCategory = {
      id: Date.now().toString(),
      name,
      color,
      description
    };
    setCategories([...categories, newCategory]);
    toast.success('Kategori eklendi');
  };

  const deleteCategory = (id: string) => {
    setCategories(categories.filter(c => c.id !== id));
    toast.success('Kategori silindi');
  };

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || template.type === selectedType;
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    
    return matchesSearch && matchesType && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Mail Şablonları</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            E-posta ve WhatsApp mesaj şablonlarınızı yönetin
          </p>
        </div>
        <div className="flex space-x-3">
          <button
            onClick={() => setShowSettingsModal(true)}
            className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
          >
            <Settings className="w-4 h-4" />
            <span>Kategori Ayarları</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Yeni Şablon</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Şablon ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            />
          </div>
          
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Türler</option>
            {templateTypes.map(type => (
              <option key={type.value} value={type.value}>{type.label}</option>
            ))}
          </select>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Kategoriler</option>
            {categories.map(category => (
              <option key={category.id} value={category.name}>{category.name}</option>
            ))}
          </select>

          <button className="flex items-center justify-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            <span>Filtrele</span>
          </button>
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template, index) => (
          <motion.div
            key={template.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-all duration-200"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 
                    className="text-lg font-semibold text-gray-900 dark:text-white mb-2 cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    onClick={() => handleViewTemplate(template)}
                  >
                    {template.name}
                  </h3>
                  <div className="flex items-center space-x-2 mb-2">
                    {templateTypes.find(t => t.value === template.type) && (
                      <div className={`flex items-center space-x-1 text-sm ${templateTypes.find(t => t.value === template.type)?.color}`}>
                        {React.createElement(templateTypes.find(t => t.value === template.type)!.icon, { className: "w-4 h-4" })}
                        <span>{templateTypes.find(t => t.value === template.type)?.label}</span>
                      </div>
                    )}
                  </div>
                  {template.subject && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2 truncate">
                      <strong>Konu:</strong> {template.subject}
                    </p>
                  )}
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(template.category)}`}>
                  {template.category}
                </span>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-3">
                  {template.content}
                </p>
              </div>

              {template.variables.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Değişkenler:</p>
                  <div className="flex flex-wrap gap-1">
                    {template.variables.slice(0, 3).map((variable, idx) => (
                      <span key={idx} className="inline-block bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded text-xs">
                        {variable}
                      </span>
                    ))}
                    {template.variables.length > 3 && (
                      <span className="inline-block bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded text-xs">
                        +{template.variables.length - 3}
                      </span>
                    )}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {format(new Date(template.updated_at), 'dd MMM yyyy', { locale: tr })}
                </span>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleCopyTemplate(template)}
                    className="p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    title="Kopyala"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleViewTemplate(template)}
                    className="p-2 text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors"
                    title="Görüntüle"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleEditClick(template)}
                    className="p-2 text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                    title="Düzenle"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleDeleteTemplate(template.id)}
                    className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Şablon bulunamadı
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Arama kriterlerinize uygun şablon bulunamadı.
          </p>
        </div>
      )}

      {/* Add Template Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Yeni Şablon Oluştur</h2>
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Şablon Adı *
                        </label>
                        <input
                          type="text"
                          value={newTemplate.name}
                          onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Şablon adını girin"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Tür *
                        </label>
                        <select
                          value={newTemplate.type}
                          onChange={(e) => setNewTemplate({ ...newTemplate, type: e.target.value as any })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        >
                          {templateTypes.map(type => (
                            <option key={type.value} value={type.value}>{type.label}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Kategori
                      </label>
                      <select
                        value={newTemplate.category}
                        onChange={(e) => setNewTemplate({ ...newTemplate, category: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        {categories.map(category => (
                          <option key={category.id} value={category.name}>{category.name}</option>
                        ))}
                      </select>
                    </div>

                    {newTemplate.type === 'email' && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          E-posta Konusu *
                        </label>
                        <input
                          type="text"
                          value={newTemplate.subject}
                          onChange={(e) => setNewTemplate({ ...newTemplate, subject: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="E-posta konusu"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        İçerik *
                      </label>
                      <textarea
                        value={newTemplate.content}
                        onChange={(e) => setNewTemplate({ ...newTemplate, content: e.target.value })}
                        rows={newTemplate.type === 'whatsapp' ? 6 : 12}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white font-mono text-sm"
                        placeholder={newTemplate.type === 'whatsapp' ? 'WhatsApp mesaj içeriği...' : 'E-posta içeriği...'}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3 flex items-center space-x-2">
                        <Code className="w-4 h-4" />
                        <span>Değişkenler</span>
                      </h3>
                      <div className="space-y-2">
                        {commonVariables.map(variable => (
                          <button
                            key={variable}
                            onClick={() => insertVariable(variable)}
                            className="w-full text-left px-2 py-1 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                          >
                            {variable}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3 flex items-center space-x-2">
                        <Type className="w-4 h-4" />
                        <span>Önizleme</span>
                      </h3>
                      <div className="text-xs text-gray-600 dark:text-gray-400 bg-white dark:bg-gray-800 p-3 rounded border max-h-40 overflow-y-auto">
                        {newTemplate.type === 'email' && newTemplate.subject && (
                          <div className="mb-2">
                            <strong>Konu:</strong> {newTemplate.subject}
                          </div>
                        )}
                        <div className="whitespace-pre-wrap">
                          {newTemplate.content || 'İçerik buraya gelecek...'}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleAddTemplate}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Kaydet</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Template Modal */}
      <AnimatePresence>
        {showEditModal && editingTemplate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Şablon Düzenle</h2>
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Şablon Adı *
                        </label>
                        <input
                          type="text"
                          value={editingTemplate.name}
                          onChange={(e) => setEditingTemplate({ ...editingTemplate, name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Şablon adını girin"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Tür *
                        </label>
                        <select
                          value={editingTemplate.type}
                          onChange={(e) => setEditingTemplate({ ...editingTemplate, type: e.target.value as any })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        >
                          {templateTypes.map(type => (
                            <option key={type.value} value={type.value}>{type.label}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Kategori
                      </label>
                      <select
                        value={editingTemplate.category}
                        onChange={(e) => setEditingTemplate({ ...editingTemplate, category: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        {categories.map(category => (
                          <option key={category.id} value={category.name}>{category.name}</option>
                        ))}
                      </select>
                    </div>

                    {editingTemplate.type === 'email' && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          E-posta Konusu *
                        </label>
                        <input
                          type="text"
                          value={editingTemplate.subject}
                          onChange={(e) => setEditingTemplate({ ...editingTemplate, subject: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="E-posta konusu"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        İçerik *
                      </label>
                      <textarea
                        value={editingTemplate.content}
                        onChange={(e) => setEditingTemplate({ ...editingTemplate, content: e.target.value })}
                        rows={editingTemplate.type === 'whatsapp' ? 6 : 12}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white font-mono text-sm"
                        placeholder={editingTemplate.type === 'whatsapp' ? 'WhatsApp mesaj içeriği...' : 'E-posta içeriği...'}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3 flex items-center space-x-2">
                        <Code className="w-4 h-4" />
                        <span>Değişkenler</span>
                      </h3>
                      <div className="space-y-2">
                        {commonVariables.map(variable => (
                          <button
                            key={variable}
                            onClick={() => insertVariable(variable, true)}
                            className="w-full text-left px-2 py-1 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                          >
                            {variable}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3 flex items-center space-x-2">
                        <Type className="w-4 h-4" />
                        <span>Önizleme</span>
                      </h3>
                      <div className="text-xs text-gray-600 dark:text-gray-400 bg-white dark:bg-gray-800 p-3 rounded border max-h-40 overflow-y-auto">
                        {editingTemplate.type === 'email' && editingTemplate.subject && (
                          <div className="mb-2">
                            <strong>Konu:</strong> {editingTemplate.subject}
                          </div>
                        )}
                        <div className="whitespace-pre-wrap">
                          {editingTemplate.content || 'İçerik buraya gelecek...'}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleEditTemplate}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Güncelle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* View Template Modal */}
      <AnimatePresence>
        {showDetailModal && selectedTemplate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">{selectedTemplate.name}</h2>
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Tür:</span>
                      <p className="text-gray-900 dark:text-white">{templateTypes.find(t => t.value === selectedTemplate.type)?.label}</p>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Kategori:</span>
                      <p className="text-gray-900 dark:text-white">{selectedTemplate.category}</p>
                    </div>
                  </div>

                  {selectedTemplate.subject && (
                    <div>
                      <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Konu:</span>
                      <p className="text-gray-900 dark:text-white">{selectedTemplate.subject}</p>
                    </div>
                  )}

                  <div>
                    <span className="text-sm font-medium text-gray-500 dark:text-gray-400">İçerik:</span>
                    <div className="mt-2 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <pre className="whitespace-pre-wrap text-sm text-gray-900 dark:text-white font-mono">
                        {selectedTemplate.content}
                      </pre>
                    </div>
                  </div>

                  {selectedTemplate.variables.length > 0 && (
                    <div>
                      <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Değişkenler:</span>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {selectedTemplate.variables.map((variable, idx) => (
                          <span key={idx} className="inline-block bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 px-2 py-1 rounded text-sm">
                            {variable}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4 text-sm text-gray-500 dark:text-gray-400">
                    <div>
                      <span className="font-medium">Oluşturulma:</span>
                      <p>{format(new Date(selectedTemplate.created_at), 'dd MMM yyyy HH:mm', { locale: tr })}</p>
                    </div>
                    <div>
                      <span className="font-medium">Son Güncelleme:</span>
                      <p>{format(new Date(selectedTemplate.updated_at), 'dd MMM yyyy HH:mm', { locale: tr })}</p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => handleCopyTemplate(selectedTemplate)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center space-x-2"
                  >
                    <Copy className="w-4 h-4" />
                    <span>Kopyala</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowDetailModal(false);
                      handleEditClick(selectedTemplate);
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Düzenle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettingsModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Kategori Ayarları</h2>
                  <button
                    onClick={() => setShowSettingsModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Şablon Kategorileri</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {categories.map(category => (
                      <div key={category.id} className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded">
                        <div className="flex items-center space-x-3">
                          <div className="w-4 h-4 rounded-full" style={{ backgroundColor: category.color }} />
                          <div>
                            <span className="text-sm font-medium text-gray-900 dark:text-white">{category.name}</span>
                            {category.description && (
                              <p className="text-xs text-gray-500 dark:text-gray-400">{category.description}</p>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={() => deleteCategory(category.id)}
                          className="text-red-600 hover:text-red-500 dark:text-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-gray-200 dark:border-gray-600 pt-4">
                    <h4 className="text-md font-medium text-gray-900 dark:text-white mb-3">Yeni Kategori Ekle</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <input
                        type="text"
                        placeholder="Kategori adı"
                        className="px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-800 dark:text-white"
                        id="category-name"
                      />
                      <input
                        type="color"
                        className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-800"
                        id="category-color"
                        defaultValue="#3B82F6"
                      />
                      <input
                        type="text"
                        placeholder="Açıklama (opsiyonel)"
                        className="px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded dark:bg-gray-800 dark:text-white"
                        id="category-description"
                      />
                    </div>
                    <button
                      onClick={() => {
                        const nameInput = document.getElementById('category-name') as HTMLInputElement;
                        const colorInput = document.getElementById('category-color') as HTMLInputElement;
                        const descInput = document.getElementById('category-description') as HTMLInputElement;
                        if (nameInput.value.trim()) {
                          addCategory(nameInput.value.trim(), colorInput.value, descInput.value.trim());
                          nameInput.value = '';
                          colorInput.value = '#3B82F6';
                          descInput.value = '';
                        }
                      }}
                      className="mt-3 w-full px-3 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 flex items-center justify-center space-x-2"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Kategori Ekle</span>
                    </button>
                  </div>
                </div>

                <div className="flex justify-end mt-6">
                  <button
                    onClick={() => setShowSettingsModal(false)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                  >
                    Tamam
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default EmailTemplates;
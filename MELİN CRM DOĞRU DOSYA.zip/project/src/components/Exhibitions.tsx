import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  Eye,
  MapPin,
  Users,
  FileText,
  X,
  Save,
  Building2,
  Mail,
  MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';

interface Exhibition {
  id: string;
  name: string;
  date: string;
  end_date?: string;
  category: string;
  city: string;
  venue?: string;
  description?: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface Company {
  id: string;
  exhibition_id: string;
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  status: string;
}

interface Quotation {
  id: string;
  company_id: string;
  company_name: string;
  title: string;
  type: string;
  status: string;
  amount: number;
  created_at: string;
}

const Exhibitions: React.FC = () => {
  const [exhibitions, setExhibitions] = useState<Exhibition[]>([
    {
      id: '1',
      name: 'İstanbul Yapı Fuarı 2024',
      date: '2024-03-15',
      end_date: '2024-03-18',
      category: 'Yapı ve İnşaat',
      city: 'İstanbul',
      venue: 'CNR Expo',
      description: 'Türkiye\'nin en büyük yapı fuarı',
      status: 'Aktif',
      created_at: '2024-01-01T00:00:00Z',
      updated_at: '2024-01-01T00:00:00Z'
    },
    {
      id: '2',
      name: 'Ankara Teknoloji Fuarı',
      date: '2024-04-20',
      end_date: '2024-04-23',
      category: 'Teknoloji',
      city: 'Ankara',
      venue: 'ATO Congresium',
      description: 'Teknoloji ve inovasyon fuarı',
      status: 'Planlama',
      created_at: '2024-01-02T00:00:00Z',
      updated_at: '2024-01-02T00:00:00Z'
    },
    {
      id: '3',
      name: 'İzmir Gıda Fuarı 2024',
      date: '2024-05-10',
      end_date: '2024-05-13',
      category: 'Gıda ve İçecek',
      city: 'İzmir',
      venue: 'Fuar İzmir',
      description: 'Gıda sektörü fuarı',
      status: 'Tamamlandı',
      created_at: '2024-01-03T00:00:00Z',
      updated_at: '2024-01-03T00:00:00Z'
    }
  ]);

  const [companies] = useState<Company[]>([
    {
      id: '1',
      exhibition_id: '1',
      name: 'ABC İnşaat Ltd. Şti.',
      contact_person: 'Mehmet Yılmaz',
      email: 'mehmet@abcinsaat.com',
      phone: '+90 212 555 0101',
      status: 'Teklif Gönderildi'
    },
    {
      id: '2',
      exhibition_id: '2',
      name: 'XYZ Teknoloji A.Ş.',
      contact_person: 'Ayşe Demir',
      email: 'ayse@xyztek.com',
      phone: '+90 312 444 0202',
      status: 'Teklif Olumlu'
    },
    {
      id: '3',
      exhibition_id: '3',
      name: 'DEF Gıda San. Tic.',
      contact_person: 'Fatma Kaya',
      email: 'fatma@defgida.com',
      phone: '+90 232 333 0303',
      status: 'Geri Dönüş Bekleniyor'
    }
  ]);

  const [quotations] = useState<Quotation[]>([
    {
      id: '1',
      company_id: '1',
      company_name: 'ABC İnşaat Ltd. Şti.',
      title: 'Stand Projesi Teklifi',
      type: 'Stand Projesi',
      status: 'Gönderildi',
      amount: 25000,
      created_at: '2024-01-15T00:00:00Z'
    },
    {
      id: '2',
      company_id: '2',
      company_name: 'XYZ Teknoloji A.Ş.',
      title: 'Hostes ve Catering Teklifi',
      type: 'Hostes & Catering',
      status: 'Onaylandı',
      amount: 15000,
      created_at: '2024-01-16T00:00:00Z'
    },
    {
      id: '3',
      company_id: '3',
      company_name: 'DEF Gıda San. Tic.',
      title: 'Şirket Tanıtım Paketi',
      type: 'Şirket Tanıtımı',
      status: 'Taslak',
      amount: 8000,
      created_at: '2024-01-17T00:00:00Z'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showCompaniesModal, setShowCompaniesModal] = useState(false);
  const [showQuotationsModal, setShowQuotationsModal] = useState(false);
  const [selectedExhibition, setSelectedExhibition] = useState<Exhibition | null>(null);
  const [editingExhibition, setEditingExhibition] = useState<Exhibition | null>(null);

  const [newExhibition, setNewExhibition] = useState({
    name: '',
    date: '',
    end_date: '',
    category: '',
    city: '',
    venue: '',
    description: '',
    status: 'Planlama'
  });

  const categories = ['Yapı ve İnşaat', 'Teknoloji', 'Gıda ve İçecek', 'Tekstil', 'Otomotiv', 'Sağlık', 'Eğitim'];
  const statuses = ['Planlama', 'Aktif', 'Tamamlandı', 'İptal'];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Aktif': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'Planlama': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'Tamamlandı': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
      case 'İptal': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const handleAddExhibition = () => {
    if (!newExhibition.name || !newExhibition.date || !newExhibition.category || !newExhibition.city) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    const exhibition: Exhibition = {
      id: Date.now().toString(),
      ...newExhibition,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    setExhibitions([...exhibitions, exhibition]);
    setNewExhibition({
      name: '',
      date: '',
      end_date: '',
      category: '',
      city: '',
      venue: '',
      description: '',
      status: 'Planlama'
    });
    setShowAddModal(false);
    toast.success('Fuar başarıyla eklendi');
  };

  const handleEditExhibition = () => {
    if (!editingExhibition) return;

    const updatedExhibition = {
      ...editingExhibition,
      updated_at: new Date().toISOString()
    };

    setExhibitions(exhibitions.map(exhibition => 
      exhibition.id === editingExhibition.id ? updatedExhibition : exhibition
    ));
    setShowEditModal(false);
    setEditingExhibition(null);
    toast.success('Fuar başarıyla güncellendi');
  };

  const handleDeleteExhibition = (id: string) => {
    if (window.confirm('Bu fuarı silmek istediğinizden emin misiniz?')) {
      setExhibitions(exhibitions.filter(exhibition => exhibition.id !== id));
      toast.success('Fuar başarıyla silindi');
    }
  };

  const handleViewExhibition = (exhibition: Exhibition) => {
    setSelectedExhibition(exhibition);
    setShowDetailModal(true);
  };

  const handleEditClick = (exhibition: Exhibition) => {
    setEditingExhibition({ ...exhibition });
    setShowEditModal(true);
  };

  const handleViewCompanies = (exhibition: Exhibition) => {
    setSelectedExhibition(exhibition);
    setShowCompaniesModal(true);
  };

  const handleViewQuotations = (exhibition: Exhibition) => {
    setSelectedExhibition(exhibition);
    setShowQuotationsModal(true);
  };

  const getExhibitionCompanies = (exhibitionId: string) => {
    return companies.filter(company => company.exhibition_id === exhibitionId);
  };

  const getExhibitionQuotations = (exhibitionId: string) => {
    const exhibitionCompanies = getExhibitionCompanies(exhibitionId);
    return quotations.filter(quotation => 
      exhibitionCompanies.some(company => company.id === quotation.company_id)
    );
  };

  const filteredExhibitions = exhibitions.filter(exhibition => {
    const matchesSearch = exhibition.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         exhibition.city.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || exhibition.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || exhibition.status === selectedStatus;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Fuarlar</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Fuar etkinliklerinizi yönetin
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Yeni Fuar</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Fuar ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            />
          </div>
          
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Kategoriler</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Durumlar</option>
            {statuses.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>

          <button className="flex items-center justify-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            <span>Filtrele</span>
          </button>
        </div>
      </div>

      {/* Exhibitions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredExhibitions.map((exhibition, index) => (
          <motion.div
            key={exhibition.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-all duration-200"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 
                    className="text-lg font-semibold text-gray-900 dark:text-white mb-2 cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    onClick={() => handleViewExhibition(exhibition)}
                  >
                    {exhibition.name}
                  </h3>
                  <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4" />
                      <span>{format(new Date(exhibition.date), 'dd MMMM yyyy', { locale: tr })}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4" />
                      <span>{exhibition.city}</span>
                    </div>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(exhibition.status)}`}>
                  {exhibition.status}
                </span>
              </div>

              <div className="space-y-2 mb-4">
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  <span className="font-medium">Kategori:</span> {exhibition.category}
                </div>
                {exhibition.venue && (
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    <span className="font-medium">Mekan:</span> {exhibition.venue}
                  </div>
                )}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">
                    {getExhibitionCompanies(exhibition.id).length} Firma
                  </span>
                  <span className="text-gray-500 dark:text-gray-400">
                    {getExhibitionQuotations(exhibition.id).length} Teklif
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleViewCompanies(exhibition)}
                    className="flex-1 px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors flex items-center justify-center space-x-2 text-sm"
                  >
                    <Building2 className="w-4 h-4" />
                    <span>Tüm Firmaları Görüntüle</span>
                  </button>
                </div>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleViewQuotations(exhibition)}
                    className="flex-1 px-3 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors flex items-center justify-center space-x-2 text-sm"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Tüm Teklifleri Görüntüle</span>
                  </button>
                </div>
                <div className="flex justify-between pt-2">
                  <div className="flex space-x-2">
                    <button 
                      onClick={() => handleViewExhibition(exhibition)}
                      className="p-2 text-gray-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
                      title="Görüntüle"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleEditClick(exhibition)}
                      className="p-2 text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                      title="Düzenle"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleDeleteExhibition(exhibition.id)}
                      className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                      title="Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredExhibitions.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Fuar bulunamadı
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Arama kriterlerinize uygun fuar bulunamadı.
          </p>
        </div>
      )}

      {/* Companies Modal */}
      <AnimatePresence>
        {showCompaniesModal && selectedExhibition && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    {selectedExhibition.name} - Firmalar
                  </h2>
                  <button
                    onClick={() => setShowCompaniesModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  {getExhibitionCompanies(selectedExhibition.id).map((company) => (
                    <div key={company.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white">{company.name}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{company.contact_person}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{company.email}</p>
                          {company.phone && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">{company.phone}</p>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400">
                            {company.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                  {getExhibitionCompanies(selectedExhibition.id).length === 0 && (
                    <div className="text-center py-8">
                      <Building2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 dark:text-gray-400">Bu fuara kayıtlı firma bulunmuyor.</p>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quotations Modal */}
      <AnimatePresence>
        {showQuotationsModal && selectedExhibition && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    {selectedExhibition.name} - Teklifler
                  </h2>
                  <button
                    onClick={() => setShowQuotationsModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  {getExhibitionQuotations(selectedExhibition.id).map((quotation) => (
                    <div key={quotation.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white">{quotation.title}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{quotation.company_name}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Tür: {quotation.type}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            Tutar: {quotation.amount.toLocaleString('tr-TR')} ₺
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                            {quotation.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                  {getExhibitionQuotations(selectedExhibition.id).length === 0 && (
                    <div className="text-center py-8">
                      <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 dark:text-gray-400">Bu fuara ait teklif bulunmuyor.</p>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetailModal && selectedExhibition && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    Fuar Detayları
                  </h2>
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Fuar Adı
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedExhibition.name}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Kategori
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedExhibition.category}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Başlangıç Tarihi
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {format(new Date(selectedExhibition.date), 'dd MMMM yyyy', { locale: tr })}
                      </p>
                    </div>
                    {selectedExhibition.end_date && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Bitiş Tarihi
                        </label>
                        <p className="text-gray-900 dark:text-white">
                          {format(new Date(selectedExhibition.end_date), 'dd MMMM yyyy', { locale: tr })}
                        </p>
                      </div>
                    )}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Şehir
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedExhibition.city}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Durum
                      </label>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedExhibition.status)}`}>
                        {selectedExhibition.status}
                      </span>
                    </div>
                  </div>
                  
                  {selectedExhibition.venue && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Mekan
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedExhibition.venue}</p>
                    </div>
                  )}

                  {selectedExhibition.description && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Açıklama
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedExhibition.description}</p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Oluşturulma Tarihi
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {format(new Date(selectedExhibition.created_at), 'dd MMMM yyyy HH:mm', { locale: tr })}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Son Güncelleme
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {format(new Date(selectedExhibition.updated_at), 'dd MMMM yyyy HH:mm', { locale: tr })}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Kayıtlı Firmalar
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {getExhibitionCompanies(selectedExhibition.id).length} firma
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Toplam Teklifler
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {getExhibitionQuotations(selectedExhibition.id).length} teklif
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    Kapat
                  </button>
                  <button
                    onClick={() => {
                      setShowDetailModal(false);
                      handleEditClick(selectedExhibition);
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Düzenle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Exhibition Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Yeni Fuar Ekle</h2>
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Fuar Adı *
                    </label>
                    <input
                      type="text"
                      value={newExhibition.name}
                      onChange={(e) => setNewExhibition({ ...newExhibition, name: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Fuar adını girin"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Başlangıç Tarihi *
                      </label>
                      <input
                        type="date"
                        value={newExhibition.date}
                        onChange={(e) => setNewExhibition({ ...newExhibition, date: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Bitiş Tarihi
                      </label>
                      <input
                        type="date"
                        value={newExhibition.end_date}
                        onChange={(e) => setNewExhibition({ ...newExhibition, end_date: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Kategori *
                      </label>
                      <select
                        value={newExhibition.category}
                        onChange={(e) => setNewExhibition({ ...newExhibition, category: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        <option value="">Kategori seçin</option>
                        {categories.map(category => (
                          <option key={category} value={category}>{category}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Şehir *
                      </label>
                      <input
                        type="text"
                        value={newExhibition.city}
                        onChange={(e) => setNewExhibition({ ...newExhibition, city: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Şehir adı"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Mekan
                      </label>
                      <input
                        type="text"
                        value={newExhibition.venue}
                        onChange={(e) => setNewExhibition({ ...newExhibition, venue: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Fuar merkezi"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Durum
                      </label>
                      <select
                        value={newExhibition.status}
                        onChange={(e) => setNewExhibition({ ...newExhibition, status: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        {statuses.map(status => (
                          <option key={status} value={status}>{status}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Açıklama
                    </label>
                    <textarea
                      value={newExhibition.description}
                      onChange={(e) => setNewExhibition({ ...newExhibition, description: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Fuar hakkında açıklama"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleAddExhibition}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Kaydet</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Exhibition Modal */}
      <AnimatePresence>
        {showEditModal && editingExhibition && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Fuar Düzenle</h2>
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Fuar Adı *
                    </label>
                    <input
                      type="text"
                      value={editingExhibition.name}
                      onChange={(e) => setEditingExhibition({ ...editingExhibition, name: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Fuar adını girin"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Başlangıç Tarihi *
                      </label>
                      <input
                        type="date"
                        value={editingExhibition.date}
                        onChange={(e) => setEditingExhibition({ ...editingExhibition, date: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Bitiş Tarihi
                      </label>
                      <input
                        type="date"
                        value={editingExhibition.end_date}
                        onChange={(e) => setEditingExhibition({ ...editingExhibition, end_date: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Kategori *
                      </label>
                      <select
                        value={editingExhibition.category}
                        onChange={(e) => setEditingExhibition({ ...editingExhibition, category: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        <option value="">Kategori seçin</option>
                        {categories.map(category => (
                          <option key={category} value={category}>{category}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Şehir *
                      </label>
                      <input
                        type="text"
                        value={editingExhibition.city}
                        onChange={(e) => setEditingExhibition({ ...editingExhibition, city: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Şehir adı"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Mekan
                      </label>
                      <input
                        type="text"
                        value={editingExhibition.venue}
                        onChange={(e) => setEditingExhibition({ ...editingExhibition, venue: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Fuar merkezi"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Durum
                      </label>
                      <select
                        value={editingExhibition.status}
                        onChange={(e) => setEditingExhibition({ ...editingExhibition, status: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        {statuses.map(status => (
                          <option key={status} value={status}>{status}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Açıklama
                    </label>
                    <textarea
                      value={editingExhibition.description}
                      onChange={(e) => setEditingExhibition({ ...editingExhibition, description: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Fuar hakkında açıklama"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleEditExhibition}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Güncelle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Exhibitions;
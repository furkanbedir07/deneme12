import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Auth helpers
export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

export const resetPassword = async (email: string) => {
  const { error } = await supabase.auth.resetPasswordForEmail(email);
  return { error };
};

// Database helpers
export const getExhibitions = async () => {
  const { data, error } = await supabase
    .from('exhibitions')
    .select('*')
    .order('date', { ascending: true });
  return { data, error };
};

export const getCompanies = async () => {
  const { data, error } = await supabase
    .from('companies')
    .select(`
      *,
      exhibitions (
        name,
        date
      )
    `)
    .order('created_at', { ascending: false });
  return { data, error };
};

export const getQuotations = async () => {
  const { data, error } = await supabase
    .from('quotations')
    .select(`
      *,
      companies (
        name,
        contact_person,
        email,
        exhibitions (
          name
        )
      )
    `)
    .order('created_at', { ascending: false });
  return { data, error };
};

export const getEmailTemplates = async () => {
  const { data, error } = await supabase
    .from('email_templates')
    .select('*')
    .order('created_at', { ascending: false });
  return { data, error };
};

export const getPersonnel = async () => {
  const { data, error } = await supabase
    .from('personnel')
    .select('*')
    .order('created_at', { ascending: false });
  return { data, error };
};

export const getSettings = async () => {
  const { data, error } = await supabase
    .from('settings')
    .select('*')
    .single();
  return { data, error };
};

// WhatsApp Web integration
export const sendWhatsAppMessage = (phone: string, message: string) => {
  // Clean phone number (remove spaces, dashes, etc.)
  const cleanPhone = phone.replace(/[^\d+]/g, '');
  
  // Encode message for URL
  const encodedMessage = encodeURIComponent(message);
  
  // Create WhatsApp Web URL
  const whatsappUrl = `https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodedMessage}`;
  
  // Open in new tab
  window.open(whatsappUrl, '_blank');
};

// Email sending (will be handled by backend)
export const sendEmail = async (emailData: {
  to: string;
  subject: string;
  content: string;
  attachments?: string[];
  signature?: string;
}) => {
  // This would typically call your backend API
  // For now, we'll simulate the email sending
  console.log('Sending email:', emailData);
  
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true, message: 'Email sent successfully' });
    }, 1000);
  });
};

// File upload helper
export const uploadFile = async (file: File, bucket: string = 'attachments') => {
  const fileExt = file.name.split('.').pop();
  const fileName = `${Date.now()}.${fileExt}`;
  
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(fileName, file);
    
  if (error) {
    throw error;
  }
  
  const { data: { publicUrl } } = supabase.storage
    .from(bucket)
    .getPublicUrl(fileName);
    
  return { fileName, publicUrl };
};
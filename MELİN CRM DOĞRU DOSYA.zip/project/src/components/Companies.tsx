import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  Eye,
  Mail,
  Phone,
  Globe,
  MapPin,
  User,
  Calendar,
  X,
  Save,
  MessageSquare,
  Send,
  Upload,
  Paperclip,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';
import { sendWhatsAppMessage } from '../lib/supabase';
import RichTextEditor from './RichTextEditor';
import FileManager from './FileManager';

interface Company {
  id: string;
  exhibition_id: string;
  exhibition_name: string;
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  website?: string;
  address?: string;
  notes?: string;
  status: string;
  status_color: string;
  created_at: string;
  updated_at: string;
}

interface Exhibition {
  id: string;
  name: string;
  date: string;
  city: string;
}

interface CompanyStatus {
  id: string;
  name: string;
  color: string;
  description?: string;
}

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  type: 'email' | 'whatsapp';
}

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadDate: string;
  uploadedBy: string;
  url: string;
  category: string;
}

const Companies: React.FC = () => {
  const [companies, setCompanies] = useState<Company[]>([
    {
      id: '1',
      exhibition_id: '1',
      exhibition_name: 'İstanbul Yapı Fuarı 2024',
      name: 'ABC İnşaat Ltd. Şti.',
      contact_person: 'Mehmet Yılmaz',
      email: 'mehmet@abcinsaat.com',
      phone: '+90 212 555 0101',
      website: 'www.abcinsaat.com',
      address: 'Maslak Mahallesi, İstanbul',
      notes: 'Büyük stand projesi talep ediyor',
      status: 'Teklif Gönderildi',
      status_color: '#F59E0B',
      created_at: '2024-01-15T10:30:00Z',
      updated_at: '2024-01-15T10:30:00Z'
    },
    {
      id: '2',
      exhibition_id: '2',
      exhibition_name: 'Ankara Teknoloji Fuarı',
      name: 'XYZ Teknoloji A.Ş.',
      contact_person: 'Ayşe Demir',
      email: 'ayse@xyztek.com',
      phone: '+90 312 444 0202',
      website: 'www.xyztek.com',
      address: 'Çankaya, Ankara',
      notes: 'Teknoloji odaklı stand tasarımı',
      status: 'Teklif Olumlu',
      status_color: '#10B981',
      created_at: '2024-01-16T14:20:00Z',
      updated_at: '2024-01-18T16:20:00Z'
    },
    {
      id: '3',
      exhibition_id: '3',
      exhibition_name: 'İzmir Gıda Fuarı 2024',
      name: 'DEF Gıda San. Tic.',
      contact_person: 'Fatma Kaya',
      email: 'fatma@defgida.com',
      phone: '+90 232 333 0303',
      website: 'www.defgida.com',
      address: 'Konak, İzmir',
      notes: 'Gıda sektörü deneyimi var',
      status: 'Geri Dönüş Bekleniyor',
      status_color: '#8B5CF6',
      created_at: '2024-01-17T09:15:00Z',
      updated_at: '2024-01-17T09:15:00Z'
    }
  ]);

  const [exhibitions, setExhibitions] = useState<Exhibition[]>([
    {
      id: '1',
      name: 'İstanbul Yapı Fuarı 2024',
      date: '2024-03-15',
      city: 'İstanbul'
    },
    {
      id: '2',
      name: 'Ankara Teknoloji Fuarı',
      date: '2024-04-20',
      city: 'Ankara'
    },
    {
      id: '3',
      name: 'İzmir Gıda Fuarı 2024',
      date: '2024-05-10',
      city: 'İzmir'
    }
  ]);

  const [companyStatuses, setCompanyStatuses] = useState<CompanyStatus[]>([
    { id: '1', name: 'Yeni', color: '#3B82F6', description: 'Yeni kayıt olan firma' },
    { id: '2', name: 'Teklif Gönderildi', color: '#F59E0B', description: 'Teklif gönderilmiş firma' },
    { id: '3', name: 'Teklif Olumlu', color: '#10B981', description: 'Teklifi olumlu karşılayan firma' },
    { id: '4', name: 'Geri Dönüş Bekleniyor', color: '#8B5CF6', description: 'Geri dönüş beklenen firma' },
    { id: '5', name: 'Anlaşma Yapıldı', color: '#059669', description: 'Anlaşma yapılan firma' },
    { id: '6', name: 'İptal', color: '#EF4444', description: 'İptal olan firma' }
  ]);

  const [emailTemplates, setEmailTemplates] = useState<EmailTemplate[]>([
    {
      id: '1',
      name: 'Stand Projesi Teklifi',
      subject: 'Stand Projesi Teklifimiz - {company_name}',
      content: 'Sayın {contact_person},\n\n{exhibition_name} fuarı için hazırladığımız stand projesi teklifimizi ekte bulabilirsiniz.\n\nDetaylı bilgi için bizimle iletişime geçebilirsiniz.\n\nSaygılarımızla,\nMelin Dizayn',
      type: 'email'
    },
    {
      id: '2',
      name: 'Hostes ve Catering Teklifi',
      subject: 'Hostes ve Catering Hizmeti Teklifimiz - {company_name}',
      content: 'Merhaba {contact_person},\n\n{exhibition_name} fuarı için talep ettiğiniz hostes ve catering hizmeti teklifimizi hazırladık.\n\nDetaylar için ekteki dosyayı inceleyebilirsiniz.\n\nİyi günler,\nMelin Dizayn Ekibi',
      type: 'email'
    },
    {
      id: '3',
      name: 'Genel Bilgilendirme',
      subject: 'Fuar Hizmetlerimiz Hakkında - {company_name}',
      content: 'Sayın {contact_person},\n\n{exhibition_name} fuarı için sunduğumuz hizmetler hakkında bilgi vermek istiyoruz.\n\nDetaylı bilgi için bizimle iletişime geçebilirsiniz.\n\nSaygılarımızla,\nMelin Dizayn',
      type: 'email'
    },
    {
      id: '4',
      name: 'WhatsApp Teklif Bildirimi',
      subject: '',
      content: 'Merhaba {contact_person}, {exhibition_name} için hazırladığımız teklifimizi e-posta olarak ilettik. Geri dönüşünüzü bekliyoruz. 🙏\n\nMelin Dizayn\n📞 +90 212 555 0000',
      type: 'whatsapp'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedExhibition, setSelectedExhibition] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showFileManager, setShowFileManager] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);

  const [newCompany, setNewCompany] = useState({
    exhibition_id: '',
    name: '',
    contact_person: '',
    email: '',
    phone: '',
    website: '',
    address: '',
    notes: '',
    status: '1'
  });

  const [emailForm, setEmailForm] = useState({
    template_id: '',
    custom_subject: '',
    custom_content: '',
    attachments: [] as File[],
    selected_files: [] as UploadedFile[],
    add_signature: true
  });

  const handleAddCompany = () => {
    if (!newCompany.exhibition_id || !newCompany.name || !newCompany.contact_person || !newCompany.email) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    const exhibition = exhibitions.find(e => e.id === newCompany.exhibition_id);
    const status = companyStatuses.find(s => s.id === newCompany.status);
    
    const company: Company = {
      id: Date.now().toString(),
      ...newCompany,
      exhibition_name: exhibition?.name || '',
      status: status?.name || 'Yeni',
      status_color: status?.color || '#3B82F6',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    setCompanies([...companies, company]);
    setNewCompany({
      exhibition_id: '',
      name: '',
      contact_person: '',
      email: '',
      phone: '',
      website: '',
      address: '',
      notes: '',
      status: '1'
    });
    setShowAddModal(false);
    toast.success('Firma başarıyla eklendi');
  };

  const handleEditCompany = () => {
    if (!editingCompany) return;

    const exhibition = exhibitions.find(e => e.id === editingCompany.exhibition_id);
    const status = companyStatuses.find(s => s.name === editingCompany.status);

    const updatedCompany = {
      ...editingCompany,
      exhibition_name: exhibition?.name || editingCompany.exhibition_name,
      status_color: status?.color || editingCompany.status_color,
      updated_at: new Date().toISOString()
    };

    setCompanies(companies.map(company => 
      company.id === editingCompany.id ? updatedCompany : company
    ));
    setShowEditModal(false);
    setEditingCompany(null);
    toast.success('Firma başarıyla güncellendi');
  };

  const handleDeleteCompany = (id: string) => {
    if (window.confirm('Bu firmayı silmek istediğinizden emin misiniz?')) {
      setCompanies(companies.filter(company => company.id !== id));
      toast.success('Firma başarıyla silindi');
    }
  };

  const handleViewCompany = (company: Company) => {
    setSelectedCompany(company);
    setShowDetailModal(true);
  };

  const handleEditClick = (company: Company) => {
    setEditingCompany({ ...company });
    setShowEditModal(true);
  };

  const handleSendEmail = (company: Company) => {
    setSelectedCompany(company);
    setEmailForm({
      template_id: '',
      custom_subject: '',
      custom_content: '',
      attachments: [],
      selected_files: [],
      add_signature: true
    });
    setShowEmailModal(true);
  };

  const handleSendWhatsApp = (company: Company) => {
    if (!company.phone) {
      toast.error('Bu firmanın telefon numarası kayıtlı değil');
      return;
    }

    const whatsappTemplate = emailTemplates.find(t => t.type === 'whatsapp' && t.name === 'WhatsApp Teklif Bildirimi');
    
    if (whatsappTemplate) {
      let message = whatsappTemplate.content
        .replace('{contact_person}', company.contact_person)
        .replace('{exhibition_name}', company.exhibition_name)
        .replace('{company_name}', company.name);

      sendWhatsAppMessage(company.phone, message);
      toast.success('WhatsApp Web açılıyor...');
    } else {
      toast.error('WhatsApp şablonu bulunamadı');
    }
  };

  const handleTemplateSelect = (templateId: string) => {
    const template = emailTemplates.find(t => t.id === templateId && t.type === 'email');
    if (template && selectedCompany) {
      const subject = template.subject
        .replace('{company_name}', selectedCompany.name)
        .replace('{contact_person}', selectedCompany.contact_person)
        .replace('{exhibition_name}', selectedCompany.exhibition_name);
      
      const content = template.content
        .replace('{company_name}', selectedCompany.name)
        .replace('{contact_person}', selectedCompany.contact_person)
        .replace('{exhibition_name}', selectedCompany.exhibition_name);

      setEmailForm(prev => ({
        ...prev,
        template_id: templateId,
        custom_subject: subject,
        custom_content: content
      }));
    }
  };

  const handleSendEmailSubmit = () => {
    if (!selectedCompany || (!emailForm.template_id && !emailForm.custom_subject)) {
      toast.error('Lütfen şablon seçin veya özel konu girin');
      return;
    }

    let finalContent = emailForm.custom_content;
    if (emailForm.add_signature) {
      const signature = '\n\n---\n<p><strong>İyi çalışmalar dilerim.</strong><br>Saygılarımızla,<br><strong>Furkan Bedir</strong><br><img src="/uploads/furkan_signature.jpg" alt="İmza" style="width: 300px; height: 80px;" /></p>';
      finalContent += signature;
    }

    console.log('Email sent with content:', finalContent);
    console.log('Attachments:', emailForm.attachments);
    console.log('Selected files:', emailForm.selected_files);
    
    toast.success('E-posta başarıyla gönderildi');
    setShowEmailModal(false);
  };

  const handleFileUpload = (files: FileList | null) => {
    if (files) {
      const newFiles = Array.from(files);
      setEmailForm(prev => ({
        ...prev,
        attachments: [...prev.attachments, ...newFiles]
      }));
      toast.success(`${newFiles.length} dosya eklendi`);
    }
  };

  const removeFile = (index: number) => {
    setEmailForm(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index)
    }));
  };

  const handleFileSelect = (file: UploadedFile) => {
    setEmailForm(prev => ({
      ...prev,
      selected_files: [...prev.selected_files, file]
    }));
    setShowFileManager(false);
    toast.success(`${file.name} seçildi`);
  };

  const removeSelectedFile = (fileId: string) => {
    setEmailForm(prev => ({
      ...prev,
      selected_files: prev.selected_files.filter(f => f.id !== fileId)
    }));
  };

  const filteredCompanies = companies.filter(company => {
    const matchesSearch = company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         company.contact_person.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         company.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesExhibition = selectedExhibition === 'all' || company.exhibition_id === selectedExhibition;
    const matchesStatus = selectedStatus === 'all' || company.status === selectedStatus;
    
    return matchesSearch && matchesExhibition && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Firmalar</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Fuar katılımcı firmalarını yönetin
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Yeni Firma</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Firma ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            />
          </div>
          
          <select
            value={selectedExhibition}
            onChange={(e) => setSelectedExhibition(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Fuarlar</option>
            {exhibitions.map(exhibition => (
              <option key={exhibition.id} value={exhibition.id}>{exhibition.name}</option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Durumlar</option>
            {companyStatuses.map(status => (
              <option key={status.id} value={status.name}>{status.name}</option>
            ))}
          </select>

          <button className="flex items-center justify-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            <span>Filtrele</span>
          </button>
        </div>
      </div>

      {/* Companies Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCompanies.map((company, index) => (
          <motion.div
            key={company.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-all duration-200"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 
                    className="text-lg font-semibold text-gray-900 dark:text-white mb-2 cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    onClick={() => handleViewCompany(company)}
                  >
                    {company.name}
                  </h3>
                  <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center space-x-2">
                      <User className="w-4 h-4" />
                      <span>{company.contact_person}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4" />
                      <span>{company.exhibition_name}</span>
                    </div>
                  </div>
                </div>
                <span 
                  className="px-2 py-1 rounded-full text-xs font-medium text-white"
                  style={{ backgroundColor: company.status_color }}
                >
                  {company.status}
                </span>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                  <Mail className="w-4 h-4" />
                  <span className="truncate">{company.email}</span>
                </div>
                {company.phone && (
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                    <Phone className="w-4 h-4" />
                    <span>{company.phone}</span>
                  </div>
                )}
                {company.website && (
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                    <Globe className="w-4 h-4" />
                    <span className="truncate">{company.website}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {format(new Date(company.updated_at), 'dd MMM yyyy', { locale: tr })}
                </span>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleSendEmail(company)}
                    className="p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    title="E-posta Gönder"
                  >
                    <Mail className="w-4 h-4" />
                  </button>
                  {company.phone && (
                    <button 
                      onClick={() => handleSendWhatsApp(company)}
                      className="p-2 text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors"
                      title="WhatsApp Gönder"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                  )}
                  <button 
                    onClick={() => handleViewCompany(company)}
                    className="p-2 text-gray-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
                    title="Görüntüle"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleEditClick(company)}
                    className="p-2 text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                    title="Düzenle"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleDeleteCompany(company.id)}
                    className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredCompanies.length === 0 && (
        <div className="text-center py-12">
          <Building2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Firma bulunamadı
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Arama kriterlerinize uygun firma bulunamadı.
          </p>
        </div>
      )}

      {/* Email Modal */}
      <AnimatePresence>
        {showEmailModal && selectedCompany && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    E-posta Gönder - {selectedCompany.name}
                  </h2>
                  <button
                    onClick={() => setShowEmailModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      E-posta Şablonu
                    </label>
                    <select
                      value={emailForm.template_id}
                      onChange={(e) => handleTemplateSelect(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="">Şablon seçin</option>
                      {emailTemplates.filter(t => t.type === 'email').map(template => (
                        <option key={template.id} value={template.id}>{template.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Konu
                    </label>
                    <input
                      type="text"
                      value={emailForm.custom_subject}
                      onChange={(e) => setEmailForm({ ...emailForm, custom_subject: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="E-posta konusu"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      İçerik
                    </label>
                    <RichTextEditor
                      value={emailForm.custom_content}
                      onChange={(content) => setEmailForm({ ...emailForm, custom_content: content })}
                      placeholder="E-posta içeriğinizi yazın..."
                      showSignatureOption={true}
                      onAddSignature={() => {
                        const signature = '\n\n---\n<p><strong>İyi çalışmalar dilerim.</strong><br>Saygılarımızla,<br><strong>Furkan Bedir</strong><br><img src="/uploads/furkan_signature.jpg" alt="İmza" style="width: 300px; height: 80px;" /></p>';
                        setEmailForm(prev => ({ ...prev, custom_content: prev.custom_content + signature }));
                        toast.success('İmza eklendi');
                      }}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="add_signature"
                      checked={emailForm.add_signature}
                      onChange={(e) => setEmailForm({ ...emailForm, add_signature: e.target.checked })}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="add_signature" className="text-sm text-gray-700 dark:text-gray-300">
                      E-posta sonuna otomatik imza ekle
                    </label>
                  </div>

                  {/* File Management */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Upload New Files */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Yeni Dosya Yükle
                      </label>
                      <div 
                        className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center"
                        onDrop={(e) => {
                          e.preventDefault();
                          handleFileUpload(e.dataTransfer.files);
                        }}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          Dosyaları buraya sürükleyin veya tıklayın
                        </p>
                        <input
                          type="file"
                          multiple
                          onChange={(e) => handleFileUpload(e.target.files)}
                          className="hidden"
                          id="file-upload"
                        />
                        <label
                          htmlFor="file-upload"
                          className="cursor-pointer px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                        >
                          Dosya Seç
                        </label>
                      </div>
                      
                      {emailForm.attachments.length > 0 && (
                        <div className="mt-3 space-y-2">
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Yeni Yüklenen:</p>
                          {emailForm.attachments.map((file, index) => (
                            <div key={index} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700 rounded">
                              <div className="flex items-center space-x-2">
                                <Paperclip className="w-4 h-4 text-gray-500" />
                                <span className="text-sm text-gray-900 dark:text-white">{file.name}</span>
                                <span className="text-xs text-gray-500">({(file.size / 1024).toFixed(1)} KB)</span>
                              </div>
                              <button
                                onClick={() => removeFile(index)}
                                className="text-red-600 hover:text-red-500"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Select Existing Files */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                          Mevcut Dosyalardan Seç
                        </label>
                        <button
                          onClick={() => setShowFileManager(true)}
                          className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 transition-colors"
                        >
                          Dosya Seç
                        </button>
                      </div>
                      
                      {emailForm.selected_files.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Seçilen Dosyalar:</p>
                          {emailForm.selected_files.map((file) => (
                            <div key={file.id} className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded">
                              <div className="flex items-center space-x-2">
                                <FileText className="w-4 h-4 text-green-600" />
                                <span className="text-sm text-gray-900 dark:text-white">{file.name}</span>
                                <span className="text-xs text-gray-500">({(file.size / 1024).toFixed(1)} KB)</span>
                              </div>
                              <button
                                onClick={() => removeSelectedFile(file.id)}
                                className="text-red-600 hover:text-red-500"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowEmailModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleSendEmailSubmit}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>E-posta Gönder</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* File Manager Modal */}
      <AnimatePresence>
        {showFileManager && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Dosya Seç
                  </h3>
                  <button
                    onClick={() => setShowFileManager(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
                <FileManager
                  onFileSelect={handleFileSelect}
                  fileType="all"
                  showUpload={false}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetailModal && selectedCompany && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    Firma Detayları
                  </h2>
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Firma Adı
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedCompany.name}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        İletişim Kişisi
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedCompany.contact_person}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        E-posta
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedCompany.email}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Telefon
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedCompany.phone || 'Belirtilmemiş'}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Website
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedCompany.website || 'Belirtilmemiş'}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Durum
                      </label>
                      <span 
                        className="px-2 py-1 rounded-full text-xs font-medium text-white"
                        style={{ backgroundColor: selectedCompany.status_color }}
                      >
                        {selectedCompany.status}
                      </span>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Fuar
                    </label>
                    <p className="text-gray-900 dark:text-white">{selectedCompany.exhibition_name}</p>
                  </div>

                  {selectedCompany.address && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Adres
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedCompany.address}</p>
                    </div>
                  )}

                  {selectedCompany.notes && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Notlar
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedCompany.notes}</p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Oluşturulma Tarihi
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {format(new Date(selectedCompany.created_at), 'dd MMMM yyyy HH:mm', { locale: tr })}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Son Güncelleme
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {format(new Date(selectedCompany.updated_at), 'dd MMMM yyyy HH:mm', { locale: tr })}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    Kapat
                  </button>
                  <button
                    onClick={() => {
                      setShowDetailModal(false);
                      handleEditClick(selectedCompany);
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Düzenle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Company Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Yeni Firma Ekle</h2>
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Fuar *
                    </label>
                    <select
                      value={newCompany.exhibition_id}
                      onChange={(e) => setNewCompany({ ...newCompany, exhibition_id: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="">Fuar seçin</option>
                      {exhibitions.map(exhibition => (
                        <option key={exhibition.id} value={exhibition.id}>{exhibition.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Firma Adı *
                      </label>
                      <input
                        type="text"
                        value={newCompany.name}
                        onChange={(e) => setNewCompany({ ...newCompany, name: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Firma adını girin"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        İletişim Kişisi *
                      </label>
                      <input
                        type="text"
                        value={newCompany.contact_person}
                        onChange={(e) => setNewCompany({ ...newCompany, contact_person: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="İletişim kişisi"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        E-posta *
                      </label>
                      <input
                        type="email"
                        value={newCompany.email}
                        onChange={(e) => setNewCompany({ ...newCompany, email: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="E-posta adresi"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Telefon
                      </label>
                      <input
                        type="tel"
                        value={newCompany.phone}
                        onChange={(e) => setNewCompany({ ...newCompany, phone: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Telefon numarası"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Website
                      </label>
                      <input
                        type="url"
                        value={newCompany.website}
                        onChange={(e) => setNewCompany({ ...newCompany, website: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="www.example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Durum
                      </label>
                      <select
                        value={newCompany.status}
                        onChange={(e) => setNewCompany({ ...newCompany, status: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        {companyStatuses.map(status => (
                          <option key={status.id} value={status.id}>{status.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Adres
                    </label>
                    <textarea
                      value={newCompany.address}
                      onChange={(e) => setNewCompany({ ...newCompany, address: e.target.value })}
                      rows={2}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Firma adresi"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Notlar
                    </label>
                    <textarea
                      value={newCompany.notes}
                      onChange={(e) => setNewCompany({ ...newCompany, notes: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Firma hakkında notlar"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleAddCompany}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Kaydet</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Company Modal */}
      <AnimatePresence>
        {showEditModal && editingCompany && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Firma Düzenle</h2>
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Fuar *
                    </label>
                    <select
                      value={editingCompany.exhibition_id}
                      onChange={(e) => setEditingCompany({ ...editingCompany, exhibition_id: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="">Fuar seçin</option>
                      {exhibitions.map(exhibition => (
                        <option key={exhibition.id} value={exhibition.id}>{exhibition.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Firma Adı *
                      </label>
                      <input
                        type="text"
                        value={editingCompany.name}
                        onChange={(e) => setEditingCompany({ ...editingCompany, name: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Firma adını girin"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        İletişim Kişisi *
                      </label>
                      <input
                        type="text"
                        value={editingCompany.contact_person}
                        onChange={(e) => setEditingCompany({ ...editingCompany, contact_person: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="İletişim kişisi"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        E-posta *
                      </label>
                      <input
                        type="email"
                        value={editingCompany.email}
                        onChange={(e) => setEditingCompany({ ...editingCompany, email: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="E-posta adresi"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Telefon
                      </label>
                      <input
                        type="tel"
                        value={editingCompany.phone}
                        onChange={(e) => setEditingCompany({ ...editingCompany, phone: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="Telefon numarası"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Website
                      </label>
                      <input
                        type="url"
                        value={editingCompany.website}
                        onChange={(e) => setEditingCompany({ ...editingCompany, website: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="www.example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Durum
                      </label>
                      <select
                        value={editingCompany.status}
                        onChange={(e) => {
                          const selectedStatus = companyStatuses.find(s => s.name === e.target.value);
                          setEditingCompany({ 
                            ...editingCompany, 
                            status: e.target.value,
                            status_color: selectedStatus?.color || '#3B82F6'
                          });
                        }}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        {companyStatuses.map(status => (
                          <option key={status.id} value={status.name}>{status.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Adres
                    </label>
                    <textarea
                      value={editingCompany.address}
                      onChange={(e) => setEditingCompany({ ...editingCompany, address: e.target.value })}
                      rows={2}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Firma adresi"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Notlar
                    </label>
                    <textarea
                      value={editingCompany.notes}
                      onChange={(e) => setEditingCompany({ ...editingCompany, notes: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Firma hakkında notlar"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleEditCompany}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Güncelle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Companies;
export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user';
  smtp_host?: string;
  smtp_port?: number;
  smtp_username?: string;
  smtp_password?: string;
  signature_path?: string;
  created_at: string;
  updated_at: string;
}

export interface Exhibition {
  id: string;
  name: string;
  date: string;
  category: string;
  city: string;
  description?: string;
  created_at: string;
  updated_at: string;
}

export interface Company {
  id: string;
  exhibition_id: string;
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  website?: string;
  notes?: string;
  status: CompanyStatus;
  created_at: string;
  updated_at: string;
}

export interface CompanyStatus {
  id: string;
  name: string;
  color: string;
  icon: string;
  description?: string;
}

export interface Quotation {
  id: string;
  company_id: string;
  type: 'stand' | 'hostess_catering';
  status: QuotationStatus;
  pdf_path?: string;
  sent_date?: string;
  created_at: string;
  updated_at: string;
}

export interface QuotationStatus {
  id: string;
  name: string;
  color: string;
  description?: string;
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  type: 'quotation' | 'follow_up' | 'general';
  created_at: string;
  updated_at: string;
}

export interface ActivityLog {
  id: string;
  user_id: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface Settings {
  id: string;
  logo_path?: string;
  theme: 'light' | 'dark';
  company_name: string;
  company_email: string;
  company_phone: string;
  company_address: string;
  updated_at: string;
}
import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  Eye,
  Send,
  Calendar,
  Building2,
  User,
  DollarSign,
  X,
  Save,
  Mail,
  MessageSquare,
  Upload,
  Paperclip,
  FileSignature
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';
import { sendWhatsAppMessage } from '../lib/supabase';
import RichTextEditor from './RichTextEditor';
import FileManager from './FileManager';

interface Quotation {
  id: string;
  company_id: string;
  company_name: string;
  exhibition_name: string;
  title: string;
  type: string;
  amount: number;
  currency: string;
  status: string;
  sent_date?: string;
  valid_until?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

interface Company {
  id: string;
  exhibition_id: string;
  exhibition_name: string;
  name: string;
  contact_person: string;
  email: string;
  phone: string;
}

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  type: 'email' | 'whatsapp';
}

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadDate: string;
  uploadedBy: string;
  url: string;
  category: string;
}

const Quotations: React.FC = () => {
  const [quotations, setQuotations] = useState<Quotation[]>([
    {
      id: '1',
      company_id: '1',
      company_name: 'ABC İnşaat Ltd. Şti.',
      exhibition_name: 'İstanbul Yapı Fuarı 2024',
      title: 'Stand Projesi Teklifi',
      type: 'Stand Projesi',
      amount: 25000,
      currency: 'TRY',
      status: 'Gönderildi',
      sent_date: '2024-01-15T10:30:00Z',
      valid_until: '2024-02-15',
      notes: 'Özel tasarım stand projesi',
      created_at: '2024-01-15T10:30:00Z',
      updated_at: '2024-01-15T10:30:00Z'
    },
    {
      id: '2',
      company_id: '2',
      company_name: 'XYZ Teknoloji A.Ş.',
      exhibition_name: 'Ankara Teknoloji Fuarı',
      title: 'Hostes ve Catering Teklifi',
      type: 'Hostes & Catering',
      amount: 15000,
      currency: 'TRY',
      status: 'Onaylandı',
      sent_date: '2024-01-16T14:20:00Z',
      valid_until: '2024-02-16',
      notes: '3 gün hostes + catering hizmeti',
      created_at: '2024-01-16T14:20:00Z',
      updated_at: '2024-01-18T16:20:00Z'
    },
    {
      id: '3',
      company_id: '3',
      company_name: 'DEF Gıda San. Tic.',
      exhibition_name: 'İzmir Gıda Fuarı 2024',
      title: 'Şirket Tanıtım Paketi',
      type: 'Şirket Tanıtımı',
      amount: 8000,
      currency: 'TRY',
      status: 'Taslak',
      valid_until: '2024-02-20',
      notes: 'Katalog ve broşür tasarımı',
      created_at: '2024-01-17T09:15:00Z',
      updated_at: '2024-01-17T09:15:00Z'
    }
  ]);

  const [companies, setCompanies] = useState<Company[]>([
    {
      id: '1',
      exhibition_id: '1',
      exhibition_name: 'İstanbul Yapı Fuarı 2024',
      name: 'ABC İnşaat Ltd. Şti.',
      contact_person: 'Mehmet Yılmaz',
      email: 'mehmet@abcinsaat.com',
      phone: '+90 212 555 0101'
    },
    {
      id: '2',
      exhibition_id: '2',
      exhibition_name: 'Ankara Teknoloji Fuarı',
      name: 'XYZ Teknoloji A.Ş.',
      contact_person: 'Ayşe Demir',
      email: 'ayse@xyztek.com',
      phone: '+90 312 444 0202'
    },
    {
      id: '3',
      exhibition_id: '3',
      exhibition_name: 'İzmir Gıda Fuarı 2024',
      name: 'DEF Gıda San. Tic.',
      contact_person: 'Fatma Kaya',
      email: 'fatma@defgida.com',
      phone: '+90 232 333 0303'
    }
  ]);

  const [emailTemplates, setEmailTemplates] = useState<EmailTemplate[]>([
    {
      id: '1',
      name: 'Stand Projesi Teklifi',
      subject: 'Stand Projesi Teklifimiz - {company_name}',
      content: 'Sayın {contact_person},\n\n{exhibition_name} fuarı için hazırladığımız stand projesi teklifimizi ekte bulabilirsiniz.\n\nDetaylı bilgi için bizimle iletişime geçebilirsiniz.\n\nSaygılarımızla,\nMelin Dizayn',
      type: 'email'
    },
    {
      id: '2',
      name: 'Hostes ve Catering Teklifi',
      subject: 'Hostes ve Catering Hizmeti Teklifimiz - {company_name}',
      content: 'Merhaba {contact_person},\n\n{exhibition_name} fuarı için talep ettiğiniz hostes ve catering hizmeti teklifimizi hazırladık.\n\nDetaylar için ekteki dosyayı inceleyebilirsiniz.\n\nİyi günler,\nMelin Dizayn Ekibi',
      type: 'email'
    },
    {
      id: '3',
      name: 'WhatsApp Teklif Bildirimi',
      subject: '',
      content: 'Merhaba {contact_person}, {exhibition_name} için hazırladığımız {quotation_type} teklifimizi e-posta olarak ilettik. Geri dönüşünüzü bekliyoruz. 🙏\n\nMelin Dizayn\n📞 +90 212 555 0000',
      type: 'whatsapp'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showFileManager, setShowFileManager] = useState(false);
  const [selectedQuotation, setSelectedQuotation] = useState<Quotation | null>(null);
  const [editingQuotation, setEditingQuotation] = useState<Quotation | null>(null);

  const [newQuotation, setNewQuotation] = useState({
    company_id: '',
    title: '',
    type: 'Stand Projesi',
    amount: 0,
    currency: 'TRY',
    status: 'Taslak',
    valid_until: '',
    notes: ''
  });

  const [emailForm, setEmailForm] = useState({
    template_id: '',
    custom_subject: '',
    custom_content: '',
    attachments: [] as File[],
    selected_files: [] as UploadedFile[],
    add_signature: true
  });

  const quotationTypes = ['Stand Projesi', 'Hostes & Catering', 'Şirket Tanıtımı', 'Genel Hizmet'];
  const quotationStatuses = ['Taslak', 'Gönderildi', 'Görüldü', 'Değerlendiriliyor', 'Onaylandı', 'Reddedildi'];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Taslak': return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
      case 'Gönderildi': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
      case 'Görüldü': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400';
      case 'Değerlendiriliyor': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'Onaylandı': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'Reddedildi': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const handleAddQuotation = () => {
    if (!newQuotation.company_id || !newQuotation.title) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    const company = companies.find(c => c.id === newQuotation.company_id);
    const quotation: Quotation = {
      id: Date.now().toString(),
      ...newQuotation,
      company_name: company?.name || '',
      exhibition_name: company?.exhibition_name || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    setQuotations([...quotations, quotation]);
    setNewQuotation({
      company_id: '',
      title: '',
      type: 'Stand Projesi',
      amount: 0,
      currency: 'TRY',
      status: 'Taslak',
      valid_until: '',
      notes: ''
    });
    setShowAddModal(false);
    toast.success('Teklif başarıyla eklendi');
  };

  const handleEditQuotation = () => {
    if (!editingQuotation) return;

    const updatedQuotation = {
      ...editingQuotation,
      updated_at: new Date().toISOString()
    };

    setQuotations(quotations.map(quotation => 
      quotation.id === editingQuotation.id ? updatedQuotation : quotation
    ));
    setShowEditModal(false);
    setEditingQuotation(null);
    toast.success('Teklif başarıyla güncellendi');
  };

  const handleDeleteQuotation = (id: string) => {
    if (window.confirm('Bu teklifi silmek istediğinizden emin misiniz?')) {
      setQuotations(quotations.filter(quotation => quotation.id !== id));
      toast.success('Teklif başarıyla silindi');
    }
  };

  const handleViewQuotation = (quotation: Quotation) => {
    setSelectedQuotation(quotation);
    setShowDetailModal(true);
  };

  const handleEditClick = (quotation: Quotation) => {
    setEditingQuotation({ ...quotation });
    setShowEditModal(true);
  };

  const handleSendEmail = (quotation: Quotation) => {
    setSelectedQuotation(quotation);
    setEmailForm({
      template_id: '',
      custom_subject: '',
      custom_content: '',
      attachments: [],
      selected_files: [],
      add_signature: true
    });
    setShowEmailModal(true);
  };

  const handleSendWhatsApp = (quotation: Quotation) => {
    const company = companies.find(c => c.id === quotation.company_id);
    if (!company?.phone) {
      toast.error('Bu firmanın telefon numarası kayıtlı değil');
      return;
    }

    // Get WhatsApp template
    const whatsappTemplate = emailTemplates.find(t => t.type === 'whatsapp' && t.name === 'WhatsApp Teklif Bildirimi');
    
    if (whatsappTemplate) {
      let message = whatsappTemplate.content
        .replace('{contact_person}', company.contact_person)
        .replace('{exhibition_name}', quotation.exhibition_name)
        .replace('{quotation_type}', quotation.type);

      sendWhatsAppMessage(company.phone, message);
      toast.success('WhatsApp Web açılıyor...');
    } else {
      toast.error('WhatsApp şablonu bulunamadı');
    }
  };

  const handleTemplateSelect = (templateId: string) => {
    const template = emailTemplates.find(t => t.id === templateId && t.type === 'email');
    if (template && selectedQuotation) {
      const company = companies.find(c => c.id === selectedQuotation.company_id);
      if (company) {
        const subject = template.subject
          .replace('{company_name}', company.name)
          .replace('{contact_person}', company.contact_person)
          .replace('{exhibition_name}', selectedQuotation.exhibition_name);
        
        const content = template.content
          .replace('{company_name}', company.name)
          .replace('{contact_person}', company.contact_person)
          .replace('{exhibition_name}', selectedQuotation.exhibition_name)
          .replace('{quotation_type}', selectedQuotation.type);

        setEmailForm(prev => ({
          ...prev,
          template_id: templateId,
          custom_subject: subject,
          custom_content: content
        }));
      }
    }
  };

  const handleAddSignature = () => {
    const signature = '\n\n---\n<p><strong>İyi çalışmalar dilerim.</strong><br>Saygılarımızla,<br><strong>Furkan Bedir</strong><br><img src="/uploads/furkan_signature.jpg" alt="İmza" style="width: 300px; height: 80px;" /></p>';
    setEmailForm(prev => ({
      ...prev,
      custom_content: prev.custom_content + signature
    }));
    toast.success('İmza eklendi');
  };

  const handleSendEmailSubmit = () => {
    if (!selectedQuotation || (!emailForm.template_id && !emailForm.custom_subject)) {
      toast.error('Lütfen şablon seçin veya özel konu girin');
      return;
    }

    // Add signature if enabled
    let finalContent = emailForm.custom_content;
    if (emailForm.add_signature) {
      const signature = '\n\n---\n<p><strong>İyi çalışmalar dilerim.</strong><br>Saygılarımızla,<br><strong>Furkan Bedir</strong><br><img src="/uploads/furkan_signature.jpg" alt="İmza" style="width: 300px; height: 80px;" /></p>';
      finalContent += signature;
    }

    console.log('Email sent with content:', finalContent);
    console.log('Attachments:', emailForm.attachments);
    console.log('Selected files:', emailForm.selected_files);
    
    toast.success('Teklif e-postası başarıyla gönderildi');
    
    // Update quotation status
    setQuotations(quotations.map(q => 
      q.id === selectedQuotation.id 
        ? { ...q, status: 'Gönderildi', sent_date: new Date().toISOString(), updated_at: new Date().toISOString() }
        : q
    ));

    setShowEmailModal(false);
  };

  const handleFileUpload = (files: FileList | null) => {
    if (files) {
      const newFiles = Array.from(files);
      setEmailForm(prev => ({
        ...prev,
        attachments: [...prev.attachments, ...newFiles]
      }));
      toast.success(`${newFiles.length} dosya eklendi`);
    }
  };

  const removeFile = (index: number) => {
    setEmailForm(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index)
    }));
  };

  const handleFileSelect = (file: UploadedFile) => {
    setEmailForm(prev => ({
      ...prev,
      selected_files: [...prev.selected_files, file]
    }));
    setShowFileManager(false);
    toast.success(`${file.name} seçildi`);
  };

  const removeSelectedFile = (fileId: string) => {
    setEmailForm(prev => ({
      ...prev,
      selected_files: prev.selected_files.filter(f => f.id !== fileId)
    }));
  };

  const filteredQuotations = quotations.filter(quotation => {
    const matchesSearch = quotation.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         quotation.company_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || quotation.status === selectedStatus;
    const matchesType = selectedType === 'all' || quotation.type === selectedType;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Teklifler</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Fuar tekliflerinizi yönetin ve takip edin
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Yeni Teklif</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Teklif ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            />
          </div>
          
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Durumlar</option>
            {quotationStatuses.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>

          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Türler</option>
            {quotationTypes.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>

          <button className="flex items-center justify-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            <span>Filtrele</span>
          </button>
        </div>
      </div>

      {/* Quotations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredQuotations.map((quotation, index) => (
          <motion.div
            key={quotation.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-all duration-200"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 
                    className="text-lg font-semibold text-gray-900 dark:text-white mb-2 cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    onClick={() => handleViewQuotation(quotation)}
                  >
                    {quotation.title}
                  </h3>
                  <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center space-x-2">
                      <Building2 className="w-4 h-4" />
                      <span>{quotation.company_name}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4" />
                      <span>{quotation.exhibition_name}</span>
                    </div>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(quotation.status)}`}>
                  {quotation.status}
                </span>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Tür:</span>
                  <span className="font-medium text-gray-900 dark:text-white">{quotation.type}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Tutar:</span>
                  <span className="font-medium text-gray-900 dark:text-white flex items-center space-x-1">
                    <DollarSign className="w-4 h-4" />
                    <span>{quotation.amount.toLocaleString('tr-TR')} {quotation.currency}</span>
                  </span>
                </div>
                {quotation.valid_until && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Geçerlilik:</span>
                    <span className="text-gray-900 dark:text-white">
                      {format(new Date(quotation.valid_until), 'dd MMM yyyy', { locale: tr })}
                    </span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {format(new Date(quotation.updated_at), 'dd MMM yyyy', { locale: tr })}
                </span>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleSendEmail(quotation)}
                    className="p-2 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    title="E-posta Gönder"
                  >
                    <Mail className="w-4 h-4" />
                  </button>
                  {companies.find(c => c.id === quotation.company_id)?.phone && (
                    <button 
                      onClick={() => handleSendWhatsApp(quotation)}
                      className="p-2 text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors"
                      title="WhatsApp Gönder"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                  )}
                  <button 
                    onClick={() => handleViewQuotation(quotation)}
                    className="p-2 text-gray-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
                    title="Görüntüle"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleEditClick(quotation)}
                    className="p-2 text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                    title="Düzenle"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleDeleteQuotation(quotation.id)}
                    className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredQuotations.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Teklif bulunamadı
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Arama kriterlerinize uygun teklif bulunamadı.
          </p>
        </div>
      )}

      {/* Email Modal */}
      <AnimatePresence>
        {showEmailModal && selectedQuotation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    Teklif Gönder - {selectedQuotation.title}
                  </h2>
                  <button
                    onClick={() => setShowEmailModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      E-posta Şablonu
                    </label>
                    <select
                      value={emailForm.template_id}
                      onChange={(e) => handleTemplateSelect(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="">Şablon seçin</option>
                      {emailTemplates.filter(t => t.type === 'email').map(template => (
                        <option key={template.id} value={template.id}>{template.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Konu
                    </label>
                    <input
                      type="text"
                      value={emailForm.custom_subject}
                      onChange={(e) => setEmailForm({ ...emailForm, custom_subject: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="E-posta konusu"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      İçerik
                    </label>
                    <RichTextEditor
                      value={emailForm.custom_content}
                      onChange={(content) => setEmailForm({ ...emailForm, custom_content: content })}
                      placeholder="Teklif içeriğinizi yazın..."
                      showSignatureOption={true}
                      onAddSignature={handleAddSignature}
                    />
                  </div>

                  {/* Signature Option */}
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="add_signature"
                      checked={emailForm.add_signature}
                      onChange={(e) => setEmailForm({ ...emailForm, add_signature: e.target.checked })}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="add_signature" className="text-sm text-gray-700 dark:text-gray-300">
                      E-posta sonuna otomatik imza ekle
                    </label>
                  </div>

                  {/* File Management */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Upload New Files */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Yeni Dosya Yükle
                      </label>
                      <div 
                        className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center"
                        onDrop={(e) => {
                          e.preventDefault();
                          handleFileUpload(e.dataTransfer.files);
                        }}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          Dosyaları buraya sürükleyin veya tıklayın
                        </p>
                        <input
                          type="file"
                          multiple
                          onChange={(e) => handleFileUpload(e.target.files)}
                          className="hidden"
                          id="file-upload"
                        />
                        <label
                          htmlFor="file-upload"
                          className="cursor-pointer px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                        >
                          Dosya Seç
                        </label>
                      </div>
                      
                      {emailForm.attachments.length > 0 && (
                        <div className="mt-3 space-y-2">
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Yeni Yüklenen:</p>
                          {emailForm.attachments.map((file, index) => (
                            <div key={index} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-700 rounded">
                              <div className="flex items-center space-x-2">
                                <Paperclip className="w-4 h-4 text-gray-500" />
                                <span className="text-sm text-gray-900 dark:text-white">{file.name}</span>
                                <span className="text-xs text-gray-500">({(file.size / 1024).toFixed(1)} KB)</span>
                              </div>
                              <button
                                onClick={() => removeFile(index)}
                                className="text-red-600 hover:text-red-500"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Select Existing Files */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                          Mevcut Dosyalardan Seç
                        </label>
                        <button
                          onClick={() => setShowFileManager(true)}
                          className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 transition-colors"
                        >
                          Dosya Seç
                        </button>
                      </div>
                      
                      {emailForm.selected_files.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Seçilen Dosyalar:</p>
                          {emailForm.selected_files.map((file) => (
                            <div key={file.id} className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded">
                              <div className="flex items-center space-x-2">
                                <FileText className="w-4 h-4 text-green-600" />
                                <span className="text-sm text-gray-900 dark:text-white">{file.name}</span>
                                <span className="text-xs text-gray-500">({(file.size / 1024).toFixed(1)} KB)</span>
                              </div>
                              <button
                                onClick={() => removeSelectedFile(file.id)}
                                className="text-red-600 hover:text-red-500"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowEmailModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleSendEmailSubmit}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Teklif Gönder</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* File Manager Modal */}
      <AnimatePresence>
        {showFileManager && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Teklif Dosyası Seç
                  </h3>
                  <button
                    onClick={() => setShowFileManager(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
                <FileManager
                  onFileSelect={handleFileSelect}
                  fileType="pdf"
                  showUpload={false}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Quotation Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Yeni Teklif Oluştur</h2>
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Firma *
                    </label>
                    <select
                      value={newQuotation.company_id}
                      onChange={(e) => setNewQuotation({ ...newQuotation, company_id: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="">Firma seçin</option>
                      {companies.map(company => (
                        <option key={company.id} value={company.id}>{company.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Teklif Başlığı *
                    </label>
                    <input
                      type="text"
                      value={newQuotation.title}
                      onChange={(e) => setNewQuotation({ ...newQuotation, title: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Teklif başlığını girin"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Teklif Türü
                      </label>
                      <select
                        value={newQuotation.type}
                        onChange={(e) => setNewQuotation({ ...newQuotation, type: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        {quotationTypes.map(type => (
                          <option key={type} value={type}>{type}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Durum
                      </label>
                      <select
                        value={newQuotation.status}
                        onChange={(e) => setNewQuotation({ ...newQuotation, status: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        {quotationStatuses.map(status => (
                          <option key={status} value={status}>{status}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Tutar
                      </label>
                      <input
                        type="number"
                        value={newQuotation.amount}
                        onChange={(e) => setNewQuotation({ ...newQuotation, amount: Number(e.target.value) })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Para Birimi
                      </label>
                      <select
                        value={newQuotation.currency}
                        onChange={(e) => setNewQuotation({ ...newQuotation, currency: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        <option value="TRY">TRY</option>
                        <option value="USD">USD</option>
                        <option value="EUR">EUR</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Geçerlilik Tarihi
                    </label>
                    <input
                      type="date"
                      value={newQuotation.valid_until}
                      onChange={(e) => setNewQuotation({ ...newQuotation, valid_until: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Notlar
                    </label>
                    <textarea
                      value={newQuotation.notes}
                      onChange={(e) => setNewQuotation({ ...newQuotation, notes: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Teklif hakkında notlar"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleAddQuotation}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Kaydet</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Quotations;
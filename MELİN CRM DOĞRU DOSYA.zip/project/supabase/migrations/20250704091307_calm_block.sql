/*
  # Initial CRM Schema

  1. New Tables
    - `users` - User authentication and profiles
    - `exhibitions` - Exhibition/fair management
    - `companies` - Company information
    - `quotations` - Quotation management
    - `email_templates` - Email and WhatsApp templates
    - `personnel` - Staff management
    - `settings` - System settings
    - `activity_logs` - Activity tracking

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  email text UNIQUE NOT NULL,
  first_name text,
  last_name text,
  phone text,
  role text DEFAULT 'user',
  smtp_host text,
  smtp_port integer DEFAULT 587,
  smtp_username text,
  smtp_password text,
  signature_text text,
  signature_image text,
  signature_width integer DEFAULT 300,
  signature_height integer DEFAULT 80,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Exhibitions table
CREATE TABLE IF NOT EXISTS exhibitions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  date date NOT NULL,
  end_date date,
  category text NOT NULL,
  city text NOT NULL,
  venue text,
  description text,
  status text DEFAULT 'Planlama',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Companies table
CREATE TABLE IF NOT EXISTS companies (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  exhibition_id uuid REFERENCES exhibitions(id) ON DELETE CASCADE,
  name text NOT NULL,
  contact_person text NOT NULL,
  email text NOT NULL,
  phone text,
  website text,
  address text,
  notes text,
  status text DEFAULT 'Yeni',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Quotations table
CREATE TABLE IF NOT EXISTS quotations (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
  title text NOT NULL,
  type text NOT NULL,
  amount decimal(10,2) DEFAULT 0,
  currency text DEFAULT 'TRY',
  status text DEFAULT 'Taslak',
  sent_date timestamptz,
  valid_until date,
  notes text,
  attachments jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Email templates table
CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  subject text,
  content text NOT NULL,
  type text NOT NULL DEFAULT 'email',
  category text DEFAULT 'Genel',
  variables jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Personnel table
CREATE TABLE IF NOT EXISTS personnel (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  position text,
  role text DEFAULT 'Personel',
  smtp_host text,
  smtp_port integer DEFAULT 587,
  smtp_username text,
  smtp_password text,
  signature_text text,
  signature_image text,
  signature_width integer DEFAULT 300,
  signature_height integer DEFAULT 80,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Settings table
CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_name text DEFAULT 'Melin Dizayn',
  company_email text DEFAULT 'info@melindizayn.com.tr',
  company_phone text,
  company_address text,
  company_website text,
  company_logo text,
  tax_number text,
  smtp_host text,
  smtp_port integer DEFAULT 587,
  smtp_username text,
  smtp_password text,
  smtp_encryption text DEFAULT 'TLS',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Activity logs table
CREATE TABLE IF NOT EXISTS activity_logs (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid,
  action text NOT NULL,
  details text,
  entity_type text,
  entity_id uuid,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE exhibitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotations ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE personnel ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own data" ON users FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can update own data" ON users FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Authenticated users can read exhibitions" ON exhibitions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage exhibitions" ON exhibitions FOR ALL TO authenticated USING (true);

CREATE POLICY "Authenticated users can read companies" ON companies FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage companies" ON companies FOR ALL TO authenticated USING (true);

CREATE POLICY "Authenticated users can read quotations" ON quotations FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage quotations" ON quotations FOR ALL TO authenticated USING (true);

CREATE POLICY "Authenticated users can read email_templates" ON email_templates FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage email_templates" ON email_templates FOR ALL TO authenticated USING (true);

CREATE POLICY "Authenticated users can read personnel" ON personnel FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage personnel" ON personnel FOR ALL TO authenticated USING (true);

CREATE POLICY "Authenticated users can read settings" ON settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can manage settings" ON settings FOR ALL TO authenticated USING (true);

CREATE POLICY "Authenticated users can read activity_logs" ON activity_logs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert activity_logs" ON activity_logs FOR INSERT TO authenticated WITH CHECK (true);

-- Insert default admin user
INSERT INTO users (email, first_name, last_name, role) 
VALUES ('info@melindizayn.com.tr', 'Admin', 'User', 'admin')
ON CONFLICT (email) DO NOTHING;

-- Insert default settings
INSERT INTO settings (company_name, company_email) 
VALUES ('Melin Dizayn', 'info@melindizayn.com.tr')
ON CONFLICT DO NOTHING;

-- Insert sample email templates
INSERT INTO email_templates (name, subject, content, type, category) VALUES
('Stand Projesi Teklifi', 'Stand Projesi Teklifimiz - {company_name}', 'Sayın {contact_person},

{exhibition_name} fuarı için hazırladığımız stand projesi teklifimizi ekte bulabilirsiniz.

Teklif Detayları:
- Stand Alanı: {stand_area} m²
- Proje Türü: Özel Tasarım
- Teslim Süresi: {delivery_time} gün

Teklifimiz {valid_until} tarihine kadar geçerlidir.

Detaylı bilgi ve görüşme için bizimle iletişime geçebilirsiniz.

Saygılarımızla,
Melin Dizayn
Tel: +90 212 555 0000
E-posta: info@melindizayn.com.tr', 'email', 'Teklif'),

('Hostes ve Catering Teklifi', 'Hostes ve Catering Hizmeti Teklifimiz - {company_name}', 'Merhaba {contact_person},

{exhibition_name} fuarı için talep ettiğiniz hostes ve catering hizmeti teklifimizi hazırladık.

Hizmet Detayları:
- Hostes Sayısı: {hostess_count} kişi
- Hizmet Süresi: {service_days} gün
- Catering Türü: {catering_type}

Teklifimiz {valid_until} tarihine kadar geçerlidir.

Detaylar için ekteki dosyayı inceleyebilirsiniz.

İyi günler,
Melin Dizayn Ekibi', 'email', 'Teklif'),

('WhatsApp Teklif Bildirimi', '', 'Merhaba {contact_person}, {exhibition_name} için hazırladığımız teklifimizi e-posta olarak ilettik. Geri dönüşünüzü bekliyoruz. 🙏

Melin Dizayn
📞 +90 212 555 0000', 'whatsapp', 'Bildirim'),

('WhatsApp Genel Bilgi', '', 'Merhaba {contact_person}, yapmış olduğumuz görüşmeye istinaden sizlere {exhibition_name} fuarı için {service_type} teklifimizi mail olarak gönderdim. 

Buradan da sizlere bilgi vermek istedim. Sormanız veya yardıma ihtiyacınız olan herhangi bir durum olursa WhatsApp hattımızdan da bize ulaşabilirsiniz.

Melin Dizayn
📞 +90 212 555 0000', 'whatsapp', 'Bildirim')

ON CONFLICT DO NOTHING;
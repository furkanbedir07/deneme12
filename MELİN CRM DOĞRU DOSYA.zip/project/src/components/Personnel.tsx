import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  Eye,
  Mail,
  Phone,
  User,
  Shield,
  X,
  Save,
  Upload,
  Image as ImageIcon,
  Settings as SettingsIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';

interface Personnel {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  position?: string;
  role: string;
  smtp_host?: string;
  smtp_port?: number;
  smtp_username?: string;
  smtp_password?: string;
  signature_text?: string;
  signature_image?: string;
  signature_width?: number;
  signature_height?: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

const Personnel: React.FC = () => {
  const [personnel, setPersonnel] = useState<Personnel[]>([
    {
      id: '1',
      first_name: 'Furkan',
      last_name: 'Bedir',
      email: 'furkan@melinfuar.com',
      phone: '+90 212 555 0001',
      position: 'Genel Müdür',
      role: 'Admin',
      smtp_host: 'smtp.gmail.com',
      smtp_port: 587,
      smtp_username: 'furkan@melinfuar.com',
      smtp_password: '••••••••',
      signature_text: 'İyi çalışmalar dilerim.\nSaygılarımızla,\nFurkan Bedir',
      signature_image: 'furkan_signature.jpg',
      signature_width: 300,
      signature_height: 80,
      is_active: true,
      created_at: '2024-01-01T00:00:00Z',
      updated_at: '2024-01-01T00:00:00Z'
    },
    {
      id: '2',
      first_name: 'Ayşe',
      last_name: 'Yılmaz',
      email: 'ayse@melinfuar.com',
      phone: '+90 212 555 0002',
      position: 'Satış Uzmanı',
      role: 'Satış',
      smtp_host: 'smtp.gmail.com',
      smtp_port: 587,
      smtp_username: 'ayse@melinfuar.com',
      smtp_password: '••••••••',
      signature_text: 'İyi günler dilerim.\nSaygılarımızla,\nAyşe Yılmaz',
      signature_image: 'ayse_signature.jpg',
      signature_width: 300,
      signature_height: 80,
      is_active: true,
      created_at: '2024-01-02T00:00:00Z',
      updated_at: '2024-01-02T00:00:00Z'
    },
    {
      id: '3',
      first_name: 'Mehmet',
      last_name: 'Kaya',
      email: 'mehmet@melinfuar.com',
      phone: '+90 212 555 0003',
      position: 'Proje Koordinatörü',
      role: 'Koordinatör',
      smtp_host: 'smtp.gmail.com',
      smtp_port: 587,
      smtp_username: 'mehmet@melinfuar.com',
      smtp_password: '••••••••',
      signature_text: 'Saygılarımızla,\nMehmet Kaya',
      signature_image: 'mehmet_signature.jpg',
      signature_width: 300,
      signature_height: 80,
      is_active: true,
      created_at: '2024-01-03T00:00:00Z',
      updated_at: '2024-01-03T00:00:00Z'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedPersonnel, setSelectedPersonnel] = useState<Personnel | null>(null);
  const [editingPersonnel, setEditingPersonnel] = useState<Personnel | null>(null);
  const [signatureFile, setSignatureFile] = useState<File | null>(null);

  const [newPersonnel, setNewPersonnel] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    position: '',
    role: 'Personel',
    smtp_host: 'smtp.gmail.com',
    smtp_port: 587,
    smtp_username: '',
    smtp_password: '',
    signature_text: '',
    signature_image: '',
    signature_width: 300,
    signature_height: 80,
    is_active: true
  });

  const roles = ['Admin', 'Satış', 'Koordinatör', 'Personel'];

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Admin': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      case 'Satış': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400';
      case 'Koordinatör': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400';
      case 'Personel': return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const handleAddPersonnel = () => {
    if (!newPersonnel.first_name || !newPersonnel.last_name || !newPersonnel.email) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    const person: Personnel = {
      id: Date.now().toString(),
      ...newPersonnel,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    setPersonnel([...personnel, person]);
    setNewPersonnel({
      first_name: '',
      last_name: '',
      email: '',
      phone: '',
      position: '',
      role: 'Personel',
      smtp_host: 'smtp.gmail.com',
      smtp_port: 587,
      smtp_username: '',
      smtp_password: '',
      signature_text: '',
      signature_image: '',
      signature_width: 300,
      signature_height: 80,
      is_active: true
    });
    setShowAddModal(false);
    toast.success('Personel başarıyla eklendi');
  };

  const handleEditPersonnel = () => {
    if (!editingPersonnel) return;

    const updatedPersonnel = {
      ...editingPersonnel,
      updated_at: new Date().toISOString()
    };

    setPersonnel(personnel.map(person => 
      person.id === editingPersonnel.id ? updatedPersonnel : person
    ));
    setShowEditModal(false);
    setEditingPersonnel(null);
    setSignatureFile(null);
    toast.success('Personel başarıyla güncellendi');
  };

  const handleDeletePersonnel = (id: string) => {
    if (window.confirm('Bu personeli silmek istediğinizden emin misiniz?')) {
      setPersonnel(personnel.filter(person => person.id !== id));
      toast.success('Personel başarıyla silindi');
    }
  };

  const handleViewPersonnel = (person: Personnel) => {
    setSelectedPersonnel(person);
    setShowDetailModal(true);
  };

  const handleEditClick = (person: Personnel) => {
    setEditingPersonnel({ ...person });
    setShowEditModal(true);
  };

  const handleSignatureUpload = (file: File | null, isEditing: boolean = false) => {
    if (file) {
      setSignatureFile(file);
      if (isEditing && editingPersonnel) {
        setEditingPersonnel({ 
          ...editingPersonnel, 
          signature_image: file.name 
        });
      } else {
        setNewPersonnel({ 
          ...newPersonnel, 
          signature_image: file.name 
        });
      }
      toast.success('İmza dosyası yüklendi');
    }
  };

  const filteredPersonnel = personnel.filter(person => {
    const matchesSearch = person.first_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         person.last_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         person.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = selectedRole === 'all' || person.role === selectedRole;
    const matchesStatus = selectedStatus === 'all' || 
                         (selectedStatus === 'active' && person.is_active) ||
                         (selectedStatus === 'inactive' && !person.is_active);
    
    return matchesSearch && matchesRole && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Personeller</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Ekip üyelerinizi yönetin
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Yeni Personel</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Personel ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            />
          </div>
          
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Roller</option>
            {roles.map(role => (
              <option key={role} value={role}>{role}</option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
          >
            <option value="all">Tüm Durumlar</option>
            <option value="active">Aktif</option>
            <option value="inactive">Pasif</option>
          </select>

          <button className="flex items-center justify-center space-x-2 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <Filter className="w-4 h-4" />
            <span>Filtrele</span>
          </button>
        </div>
      </div>

      {/* Personnel Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPersonnel.map((person, index) => (
          <motion.div
            key={person.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-all duration-200"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 
                    className="text-lg font-semibold text-gray-900 dark:text-white mb-2 cursor-pointer hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    onClick={() => handleViewPersonnel(person)}
                  >
                    {person.first_name} {person.last_name}
                  </h3>
                  <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center space-x-2">
                      <User className="w-4 h-4" />
                      <span>{person.position || 'Pozisyon belirtilmemiş'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Mail className="w-4 h-4" />
                      <span className="truncate">{person.email}</span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRoleColor(person.role)}`}>
                    {person.role}
                  </span>
                  <div className={`w-2 h-2 rounded-full ${person.is_active ? 'bg-green-500' : 'bg-red-500'}`} />
                </div>
              </div>

              <div className="space-y-2 mb-4">
                {person.phone && (
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                    <Phone className="w-4 h-4" />
                    <span>{person.phone}</span>
                  </div>
                )}
                <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                  <Shield className="w-4 h-4" />
                  <span>{person.is_active ? 'Aktif' : 'Pasif'}</span>
                </div>
                {person.signature_image && (
                  <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                    <ImageIcon className="w-4 h-4" />
                    <span>İmza mevcut</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  {format(new Date(person.updated_at), 'dd MMM yyyy', { locale: tr })}
                </span>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => handleViewPersonnel(person)}
                    className="p-2 text-gray-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
                    title="Görüntüle"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleEditClick(person)}
                    className="p-2 text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                    title="Düzenle"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => handleDeletePersonnel(person.id)}
                    className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredPersonnel.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Personel bulunamadı
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Arama kriterlerinize uygun personel bulunamadı.
          </p>
        </div>
      )}

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetailModal && selectedPersonnel && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                    Personel Detayları
                  </h2>
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Ad
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedPersonnel.first_name}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Soyad
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedPersonnel.last_name}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        E-posta
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedPersonnel.email}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Telefon
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedPersonnel.phone || 'Belirtilmemiş'}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Pozisyon
                      </label>
                      <p className="text-gray-900 dark:text-white">{selectedPersonnel.position || 'Belirtilmemiş'}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Rol
                      </label>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRoleColor(selectedPersonnel.role)}`}>
                        {selectedPersonnel.role}
                      </span>
                    </div>
                  </div>

                  {/* SMTP Settings */}
                  <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">SMTP Ayarları</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          SMTP Host
                        </label>
                        <p className="text-gray-900 dark:text-white">{selectedPersonnel.smtp_host || 'Belirtilmemiş'}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Port
                        </label>
                        <p className="text-gray-900 dark:text-white">{selectedPersonnel.smtp_port || 'Belirtilmemiş'}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Kullanıcı Adı
                        </label>
                        <p className="text-gray-900 dark:text-white">{selectedPersonnel.smtp_username || 'Belirtilmemiş'}</p>
                      </div>
                    </div>
                  </div>

                  {/* Signature */}
                  {selectedPersonnel.signature_text && (
                    <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">İmza</h3>
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                        <div className="whitespace-pre-line text-sm text-gray-900 dark:text-white mb-2">
                          {selectedPersonnel.signature_text}
                        </div>
                        {selectedPersonnel.signature_image && (
                          <div 
                            className="bg-gray-200 dark:bg-gray-600 rounded flex items-center justify-center text-xs text-gray-500"
                            style={{ 
                              width: `${selectedPersonnel.signature_width}px`, 
                              height: `${selectedPersonnel.signature_height}px`,
                              maxWidth: '100%'
                            }}
                          >
                            {selectedPersonnel.signature_image}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Oluşturulma Tarihi
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {format(new Date(selectedPersonnel.created_at), 'dd MMMM yyyy HH:mm', { locale: tr })}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Son Güncelleme
                      </label>
                      <p className="text-gray-900 dark:text-white">
                        {format(new Date(selectedPersonnel.updated_at), 'dd MMMM yyyy HH:mm', { locale: tr })}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowDetailModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    Kapat
                  </button>
                  <button
                    onClick={() => {
                      setShowDetailModal(false);
                      handleEditClick(selectedPersonnel);
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Edit className="w-4 h-4" />
                    <span>Düzenle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Personnel Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Yeni Personel Ekle</h2>
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-6">
                  {/* Basic Info */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Temel Bilgiler</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Ad *
                        </label>
                        <input
                          type="text"
                          value={newPersonnel.first_name}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, first_name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Adını girin"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Soyad *
                        </label>
                        <input
                          type="text"
                          value={newPersonnel.last_name}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, last_name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Soyadını girin"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          E-posta *
                        </label>
                        <input
                          type="email"
                          value={newPersonnel.email}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, email: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="E-posta adresi"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Telefon
                        </label>
                        <input
                          type="tel"
                          value={newPersonnel.phone}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, phone: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Telefon numarası"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Pozisyon
                        </label>
                        <input
                          type="text"
                          value={newPersonnel.position}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, position: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Pozisyon"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Rol
                        </label>
                        <select
                          value={newPersonnel.role}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, role: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        >
                          {roles.map(role => (
                            <option key={role} value={role}>{role}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* SMTP Settings */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">SMTP Ayarları</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          SMTP Host
                        </label>
                        <input
                          type="text"
                          value={newPersonnel.smtp_host}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, smtp_host: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="smtp.gmail.com"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Port
                        </label>
                        <input
                          type="number"
                          value={newPersonnel.smtp_port}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, smtp_port: Number(e.target.value) })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="587"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Kullanıcı Adı
                        </label>
                        <input
                          type="text"
                          value={newPersonnel.smtp_username}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, smtp_username: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="E-posta adresi"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Şifre
                        </label>
                        <input
                          type="password"
                          value={newPersonnel.smtp_password}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, smtp_password: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="••••••••"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Signature Settings */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">İmza Ayarları</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          İmza Metni
                        </label>
                        <textarea
                          value={newPersonnel.signature_text}
                          onChange={(e) => setNewPersonnel({ ...newPersonnel, signature_text: e.target.value })}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="İmza metninizi girin"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          İmza Dosyası (JPG)
                        </label>
                        <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
                          <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                            {signatureFile ? signatureFile.name : 'İmza dosyanızı buraya sürükleyin veya tıklayın'}
                          </p>
                          <input
                            type="file"
                            accept=".jpg,.jpeg"
                            onChange={(e) => handleSignatureUpload(e.target.files?.[0] || null)}
                            className="hidden"
                            id="signature-upload-add"
                          />
                          <label
                            htmlFor="signature-upload-add"
                            className="cursor-pointer px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                          >
                            Dosya Seç
                          </label>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Genişlik (px)
                          </label>
                          <input
                            type="number"
                            value={newPersonnel.signature_width}
                            onChange={(e) => setNewPersonnel({ ...newPersonnel, signature_width: Number(e.target.value) })}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                            placeholder="300"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Yükseklik (px)
                          </label>
                          <input
                            type="number"
                            value={newPersonnel.signature_height}
                            onChange={(e) => setNewPersonnel({ ...newPersonnel, signature_height: Number(e.target.value) })}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                            placeholder="80"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleAddPersonnel}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Kaydet</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Personnel Modal */}
      <AnimatePresence>
        {showEditModal && editingPersonnel && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Personel Düzenle</h2>
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-6">
                  {/* Basic Info */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Temel Bilgiler</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Ad *
                        </label>
                        <input
                          type="text"
                          value={editingPersonnel.first_name}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, first_name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Adını girin"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Soyad *
                        </label>
                        <input
                          type="text"
                          value={editingPersonnel.last_name}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, last_name: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Soyadını girin"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          E-posta *
                        </label>
                        <input
                          type="email"
                          value={editingPersonnel.email}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, email: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="E-posta adresi"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Telefon
                        </label>
                        <input
                          type="tel"
                          value={editingPersonnel.phone}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, phone: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Telefon numarası"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Pozisyon
                        </label>
                        <input
                          type="text"
                          value={editingPersonnel.position}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, position: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="Pozisyon"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Rol
                        </label>
                        <select
                          value={editingPersonnel.role}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, role: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        >
                          {roles.map(role => (
                            <option key={role} value={role}>{role}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="mt-4">
                      <label className="flex items-center">
                        <input
                          type="checkbox"
                          checked={editingPersonnel.is_active}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, is_active: e.target.checked })}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Aktif</span>
                      </label>
                    </div>
                  </div>

                  {/* SMTP Settings */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">SMTP Ayarları</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          SMTP Host
                        </label>
                        <input
                          type="text"
                          value={editingPersonnel.smtp_host}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, smtp_host: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="smtp.gmail.com"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Port
                        </label>
                        <input
                          type="number"
                          value={editingPersonnel.smtp_port}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, smtp_port: Number(e.target.value) })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="587"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Kullanıcı Adı
                        </label>
                        <input
                          type="text"
                          value={editingPersonnel.smtp_username}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, smtp_username: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="E-posta adresi"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Şifre
                        </label>
                        <input
                          type="password"
                          value={editingPersonnel.smtp_password}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, smtp_password: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="••••••••"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Signature Settings */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">İmza Ayarları</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          İmza Metni
                        </label>
                        <textarea
                          value={editingPersonnel.signature_text}
                          onChange={(e) => setEditingPersonnel({ ...editingPersonnel, signature_text: e.target.value })}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="İmza metninizi girin"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          İmza Dosyası (JPG)
                        </label>
                        <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
                          <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                            {signatureFile ? signatureFile.name : editingPersonnel.signature_image || 'İmza dosyanızı buraya sürükleyin veya tıklayın'}
                          </p>
                          <input
                            type="file"
                            accept=".jpg,.jpeg"
                            onChange={(e) => handleSignatureUpload(e.target.files?.[0] || null, true)}
                            className="hidden"
                            id="signature-upload-edit"
                          />
                          <label
                            htmlFor="signature-upload-edit"
                            className="cursor-pointer px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                          >
                            Dosya Seç
                          </label>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Genişlik (px)
                          </label>
                          <input
                            type="number"
                            value={editingPersonnel.signature_width}
                            onChange={(e) => setEditingPersonnel({ ...editingPersonnel, signature_width: Number(e.target.value) })}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                            placeholder="300"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Yükseklik (px)
                          </label>
                          <input
                            type="number"
                            value={editingPersonnel.signature_height}
                            onChange={(e) => setEditingPersonnel({ ...editingPersonnel, signature_height: Number(e.target.value) })}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                            placeholder="80"
                          />
                        </div>
                      </div>

                      {/* Signature Preview */}
                      {editingPersonnel.signature_text && (
                        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                          <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">İmza Önizlemesi</h4>
                          <div className="bg-white dark:bg-gray-800 p-4 rounded border">
                            <div className="whitespace-pre-line text-sm text-gray-900 dark:text-white mb-2">
                              {editingPersonnel.signature_text}
                            </div>
                            {editingPersonnel.signature_image && (
                              <div 
                                className="bg-gray-200 dark:bg-gray-600 rounded flex items-center justify-center text-xs text-gray-500"
                                style={{ 
                                  width: `${editingPersonnel.signature_width}px`, 
                                  height: `${editingPersonnel.signature_height}px`,
                                  maxWidth: '100%'
                                }}
                              >
                                {editingPersonnel.signature_image}
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={handleEditPersonnel}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Güncelle</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Personnel;
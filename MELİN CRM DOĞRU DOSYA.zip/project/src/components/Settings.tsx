import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  User, 
  Mail, 
  Phone, 
  Upload, 
  Save, 
  Eye, 
  Image as ImageIcon,
  Server,
  Shield,
  Palette,
  Globe,
  X,
  Plus,
  Edit,
  Trash2,
  Calendar,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';

interface Status {
  id: string;
  name: string;
  color: string;
  description?: string;
}

const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState('profile');
  
  const [profileSettings, setProfileSettings] = useState({
    firstName: 'Furkan',
    lastName: 'Bedir',
    email: 'furkan@melinfuar.com',
    phone: '+90 212 555 0001',
    company: 'Melin Fuarcılık ve Organizasyon',
    position: 'Genel Müdür'
  });

  const [companySettings, setCompanySettings] = useState({
    companyName: 'Melin Fuarcılık ve Organizasyon',
    companyEmail: 'info@melinfuar.com',
    companyPhone: '+90 212 555 0000',
    companyAddress: 'Maslak Mahallesi, Büyükdere Cad. No:123, Şişli/İstanbul',
    website: 'www.melinfuar.com',
    taxNumber: '1234567890'
  });

  const [smtpSettings, setSmtpSettings] = useState({
    host: 'smtp.gmail.com',
    port: 587,
    username: 'info@melinfuar.com',
    password: '••••••••',
    encryption: 'TLS'
  });

  const [signatureSettings, setSignatureSettings] = useState({
    signatureText: 'İyi çalışmalar dilerim.\nSaygılarımızla,\nFurkan Bedir',
    signatureImage: 'furkan_signature.jpg',
    width: 300,
    height: 80,
    showPreview: false
  });

  // Fuar Durumları
  const [exhibitionStatuses, setExhibitionStatuses] = useState<Status[]>([
    { id: '1', name: 'Planlama', color: '#F59E0B', description: 'Planlama aşamasındaki fuar' },
    { id: '2', name: 'Aktif', color: '#10B981', description: 'Şu anda devam eden fuar' },
    { id: '3', name: 'Tamamlandı', color: '#3B82F6', description: 'Tamamlanmış fuar' },
    { id: '4', name: 'İptal', color: '#EF4444', description: 'İptal edilmiş fuar' },
    { id: '5', name: 'Ertelendi', color: '#8B5CF6', description: 'Ertelenmiş fuar' }
  ]);

  // Firma Durumları
  const [companyStatuses, setCompanyStatuses] = useState<Status[]>([
    { id: '1', name: 'Yeni', color: '#3B82F6', description: 'Yeni kayıt olan firma' },
    { id: '2', name: 'Teklif Gönderildi', color: '#F59E0B', description: 'Teklif gönderilmiş firma' },
    { id: '3', name: 'Görüşüldü', color: '#8B5CF6', description: 'Görüşme yapılan firma' },
    { id: '4', name: 'Arandı', color: '#06B6D4', description: 'Telefon ile aranan firma' },
    { id: '5', name: 'Teklif Olumlu', color: '#10B981', description: 'Teklifi olumlu karşılayan firma' },
    { id: '6', name: 'Geri Dönüş Bekleniyor', color: '#F97316', description: 'Geri dönüş beklenen firma' },
    { id: '7', name: 'Anlaşma Yapıldı', color: '#059669', description: 'Anlaşma yapılan firma' },
    { id: '8', name: 'İptal', color: '#EF4444', description: 'İptal olan firma' }
  ]);

  // Teklif Durumları
  const [quotationStatuses, setQuotationStatuses] = useState<Status[]>([
    { id: '1', name: 'Taslak', color: '#6B7280', description: 'Taslak halindeki teklif' },
    { id: '2', name: 'Gönderildi', color: '#3B82F6', description: 'Gönderilmiş teklif' },
    { id: '3', name: 'Görüldü', color: '#8B5CF6', description: 'Görülmüş teklif' },
    { id: '4', name: 'Değerlendiriliyor', color: '#F59E0B', description: 'Değerlendirme aşamasındaki teklif' },
    { id: '5', name: 'Onaylandı', color: '#10B981', description: 'Onaylanmış teklif' },
    { id: '6', name: 'Reddedildi', color: '#EF4444', description: 'Reddedilmiş teklif' },
    { id: '7', name: 'Revizyon Gerekli', color: '#F97316', description: 'Revizyon gereken teklif' }
  ]);

  const [showStatusModal, setShowStatusModal] = useState(false);
  const [editingStatus, setEditingStatus] = useState<Status | null>(null);
  const [currentStatusType, setCurrentStatusType] = useState<'exhibition' | 'company' | 'quotation'>('company');
  const [newStatus, setNewStatus] = useState({
    name: '',
    color: '#3B82F6',
    description: ''
  });

  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [signatureFile, setSignatureFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>('/uploads/melin_logo.png');

  const tabs = [
    { id: 'profile', name: 'Profil Bilgileri', icon: User },
    { id: 'company', name: 'Şirket Bilgileri', icon: Globe },
    { id: 'smtp', name: 'SMTP Ayarları', icon: Server },
    { id: 'signature', name: 'İmza Ayarları', icon: ImageIcon },
    { id: 'exhibition-statuses', name: 'Fuar Durumları', icon: Calendar },
    { id: 'company-statuses', name: 'Firma Durumları', icon: Palette },
    { id: 'quotation-statuses', name: 'Teklif Durumları', icon: FileText },
    { id: 'appearance', name: 'Görünüm', icon: Palette }
  ];

  const handleSaveProfile = () => {
    toast.success('Profil bilgileri güncellendi');
  };

  const handleSaveCompany = () => {
    toast.success('Şirket bilgileri güncellendi');
  };

  const handleSaveSMTP = () => {
    toast.success('SMTP ayarları güncellendi');
  };

  const handleSaveSignature = () => {
    toast.success('İmza ayarları güncellendi');
  };

  const handleLogoUpload = (file: File | null) => {
    if (file) {
      setLogoFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      toast.success('Logo yüklendi');
    }
  };

  const handleSignatureUpload = (file: File | null) => {
    if (file) {
      setSignatureFile(file);
      setSignatureSettings({ ...signatureSettings, signatureImage: file.name });
      toast.success('İmza dosyası yüklendi');
    }
  };

  const getCurrentStatuses = () => {
    switch (currentStatusType) {
      case 'exhibition': return exhibitionStatuses;
      case 'company': return companyStatuses;
      case 'quotation': return quotationStatuses;
      default: return companyStatuses;
    }
  };

  const setCurrentStatuses = (statuses: Status[]) => {
    switch (currentStatusType) {
      case 'exhibition': setExhibitionStatuses(statuses); break;
      case 'company': setCompanyStatuses(statuses); break;
      case 'quotation': setQuotationStatuses(statuses); break;
    }
  };

  const handleAddStatus = () => {
    if (!newStatus.name) {
      toast.error('Durum adı gerekli');
      return;
    }

    const status: Status = {
      id: Date.now().toString(),
      ...newStatus
    };

    const currentStatuses = getCurrentStatuses();
    setCurrentStatuses([...currentStatuses, status]);
    setNewStatus({ name: '', color: '#3B82F6', description: '' });
    setShowStatusModal(false);
    toast.success('Durum başarıyla eklendi');
  };

  const handleEditStatus = () => {
    if (!editingStatus) return;

    const currentStatuses = getCurrentStatuses();
    setCurrentStatuses(currentStatuses.map(status => 
      status.id === editingStatus.id ? editingStatus : status
    ));
    setEditingStatus(null);
    setShowStatusModal(false);
    toast.success('Durum başarıyla güncellendi');
  };

  const handleDeleteStatus = (id: string) => {
    if (window.confirm('Bu durumu silmek istediğinizden emin misiniz?')) {
      const currentStatuses = getCurrentStatuses();
      setCurrentStatuses(currentStatuses.filter(status => status.id !== id));
      toast.success('Durum başarıyla silindi');
    }
  };

  const openStatusModal = (type: 'exhibition' | 'company' | 'quotation', status?: Status) => {
    setCurrentStatusType(type);
    if (status) {
      setEditingStatus({ ...status });
    } else {
      setNewStatus({ name: '', color: '#3B82F6', description: '' });
    }
    setShowStatusModal(true);
  };

  const getStatusTypeTitle = (type: 'exhibition' | 'company' | 'quotation') => {
    switch (type) {
      case 'exhibition': return 'Fuar Durumları';
      case 'company': return 'Firma Durumları';
      case 'quotation': return 'Teklif Durumları';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Ayarlar</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Sistem ve profil ayarlarınızı yönetin
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{tab.name}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            {/* Profile Settings */}
            {activeTab === 'profile' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Profil Bilgileri</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Ad
                      </label>
                      <input
                        type="text"
                        value={profileSettings.firstName}
                        onChange={(e) => setProfileSettings({ ...profileSettings, firstName: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Soyad
                      </label>
                      <input
                        type="text"
                        value={profileSettings.lastName}
                        onChange={(e) => setProfileSettings({ ...profileSettings, lastName: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        E-posta
                      </label>
                      <input
                        type="email"
                        value={profileSettings.email}
                        onChange={(e) => setProfileSettings({ ...profileSettings, email: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Telefon
                      </label>
                      <input
                        type="tel"
                        value={profileSettings.phone}
                        onChange={(e) => setProfileSettings({ ...profileSettings, phone: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Şirket
                      </label>
                      <input
                        type="text"
                        value={profileSettings.company}
                        onChange={(e) => setProfileSettings({ ...profileSettings, company: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Pozisyon
                      </label>
                      <input
                        type="text"
                        value={profileSettings.position}
                        onChange={(e) => setProfileSettings({ ...profileSettings, position: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end mt-6">
                    <button
                      onClick={handleSaveProfile}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>Kaydet</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Company Settings */}
            {activeTab === 'company' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Şirket Bilgileri</h2>
                  
                  {/* Logo Upload */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Şirket Logosu
                    </label>
                    <div className="flex items-center space-x-6">
                      {/* Logo Preview */}
                      <div className="flex-shrink-0">
                        <div className="w-32 h-20 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center bg-gray-50 dark:bg-gray-700">
                          {logoPreview ? (
                            <img 
                              src={logoPreview} 
                              alt="Logo Preview" 
                              className="max-w-full max-h-full object-contain"
                            />
                          ) : (
                            <ImageIcon className="w-8 h-8 text-gray-400" />
                          )}
                        </div>
                      </div>
                      
                      {/* Upload Controls */}
                      <div className="flex-1">
                        <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
                          <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                            {logoFile ? logoFile.name : 'Logo dosyanızı buraya sürükleyin veya tıklayın'}
                          </p>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleLogoUpload(e.target.files?.[0] || null)}
                            className="hidden"
                            id="logo-upload"
                          />
                          <label
                            htmlFor="logo-upload"
                            className="cursor-pointer px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                          >
                            Logo Seç
                          </label>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                          Önerilen boyut: 200x100px, PNG veya JPG formatında
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Şirket Adı
                      </label>
                      <input
                        type="text"
                        value={companySettings.companyName}
                        onChange={(e) => setCompanySettings({ ...companySettings, companyName: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        E-posta
                      </label>
                      <input
                        type="email"
                        value={companySettings.companyEmail}
                        onChange={(e) => setCompanySettings({ ...companySettings, companyEmail: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Telefon
                      </label>
                      <input
                        type="tel"
                        value={companySettings.companyPhone}
                        onChange={(e) => setCompanySettings({ ...companySettings, companyPhone: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Adres
                      </label>
                      <textarea
                        value={companySettings.companyAddress}
                        onChange={(e) => setCompanySettings({ ...companySettings, companyAddress: e.target.value })}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Website
                      </label>
                      <input
                        type="url"
                        value={companySettings.website}
                        onChange={(e) => setCompanySettings({ ...companySettings, website: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Vergi Numarası
                      </label>
                      <input
                        type="text"
                        value={companySettings.taxNumber}
                        onChange={(e) => setCompanySettings({ ...companySettings, taxNumber: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end mt-6">
                    <button
                      onClick={handleSaveCompany}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>Kaydet</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* SMTP Settings */}
            {activeTab === 'smtp' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">SMTP Ayarları</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        SMTP Host
                      </label>
                      <input
                        type="text"
                        value={smtpSettings.host}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, host: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="smtp.gmail.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Port
                      </label>
                      <input
                        type="number"
                        value={smtpSettings.port}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, port: Number(e.target.value) })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="587"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Kullanıcı Adı
                      </label>
                      <input
                        type="text"
                        value={smtpSettings.username}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, username: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="E-posta adresi"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Şifre
                      </label>
                      <input
                        type="password"
                        value={smtpSettings.password}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, password: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="••••••••"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Şifreleme
                      </label>
                      <select
                        value={smtpSettings.encryption}
                        onChange={(e) => setSmtpSettings({ ...smtpSettings, encryption: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      >
                        <option value="TLS">TLS</option>
                        <option value="SSL">SSL</option>
                        <option value="None">Yok</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex justify-end mt-6">
                    <button
                      onClick={handleSaveSMTP}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>Kaydet</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Signature Settings */}
            {activeTab === 'signature' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">İmza Ayarları</h2>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        İmza Metni
                      </label>
                      <textarea
                        value={signatureSettings.signatureText}
                        onChange={(e) => setSignatureSettings({ ...signatureSettings, signatureText: e.target.value })}
                        rows={4}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="İmza metninizi girin"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        İmza Dosyası (JPG)
                      </label>
                      <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center">
                        <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          {signatureFile ? signatureFile.name : signatureSettings.signatureImage || 'İmza dosyanızı buraya sürükleyin veya tıklayın'}
                        </p>
                        <input
                          type="file"
                          accept=".jpg,.jpeg"
                          onChange={(e) => handleSignatureUpload(e.target.files?.[0] || null)}
                          className="hidden"
                          id="signature-upload"
                        />
                        <label
                          htmlFor="signature-upload"
                          className="cursor-pointer px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                        >
                          Dosya Seç
                        </label>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Genişlik (px)
                        </label>
                        <input
                          type="number"
                          value={signatureSettings.width}
                          onChange={(e) => setSignatureSettings({ ...signatureSettings, width: Number(e.target.value) })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="300"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Yükseklik (px)
                        </label>
                        <input
                          type="number"
                          value={signatureSettings.height}
                          onChange={(e) => setSignatureSettings({ ...signatureSettings, height: Number(e.target.value) })}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                          placeholder="80"
                        />
                      </div>
                    </div>

                    <div>
                      <button
                        onClick={() => setSignatureSettings({ ...signatureSettings, showPreview: !signatureSettings.showPreview })}
                        className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                        <span>{signatureSettings.showPreview ? 'Önizlemeyi Gizle' : 'Önizleme Göster'}</span>
                      </button>
                    </div>

                    {signatureSettings.showPreview && (
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                        <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">İmza Önizlemesi</h3>
                        <div className="bg-white dark:bg-gray-800 p-4 rounded border">
                          <div className="whitespace-pre-line text-sm text-gray-900 dark:text-white mb-2">
                            {signatureSettings.signatureText}
                          </div>
                          {signatureSettings.signatureImage && (
                            <img 
                              src={`/uploads/${signatureSettings.signatureImage}`}
                              alt="İmza"
                              style={{ 
                                width: `${signatureSettings.width}px`, 
                                height: `${signatureSettings.height}px`,
                                maxWidth: '100%'
                              }}
                              className="object-contain"
                            />
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-end mt-6">
                    <button
                      onClick={handleSaveSignature}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>Kaydet</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Exhibition Statuses */}
            {activeTab === 'exhibition-statuses' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Fuar Durumları</h2>
                  <button
                    onClick={() => openStatusModal('exhibition')}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Yeni Durum</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {exhibitionStatuses.map((status) => (
                    <div key={status.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div 
                          className="w-6 h-6 rounded-full"
                          style={{ backgroundColor: status.color }}
                        />
                        <div>
                          <h3 className="font-medium text-gray-900 dark:text-white">{status.name}</h3>
                          {status.description && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">{status.description}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => openStatusModal('exhibition', status)}
                          className="p-2 text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                          title="Düzenle"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteStatus(status.id)}
                          className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                          title="Sil"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Company Statuses */}
            {activeTab === 'company-statuses' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Firma Durumları</h2>
                  <button
                    onClick={() => openStatusModal('company')}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Yeni Durum</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {companyStatuses.map((status) => (
                    <div key={status.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div 
                          className="w-6 h-6 rounded-full"
                          style={{ backgroundColor: status.color }}
                        />
                        <div>
                          <h3 className="font-medium text-gray-900 dark:text-white">{status.name}</h3>
                          {status.description && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">{status.description}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => openStatusModal('company', status)}
                          className="p-2 text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                          title="Düzenle"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteStatus(status.id)}
                          className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                          title="Sil"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Quotation Statuses */}
            {activeTab === 'quotation-statuses' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">Teklif Durumları</h2>
                  <button
                    onClick={() => openStatusModal('quotation')}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Yeni Durum</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {quotationStatuses.map((status) => (
                    <div key={status.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div 
                          className="w-6 h-6 rounded-full"
                          style={{ backgroundColor: status.color }}
                        />
                        <div>
                          <h3 className="font-medium text-gray-900 dark:text-white">{status.name}</h3>
                          {status.description && (
                            <p className="text-sm text-gray-600 dark:text-gray-400">{status.description}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => openStatusModal('quotation', status)}
                          className="p-2 text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                          title="Düzenle"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteStatus(status.id)}
                          className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                          title="Sil"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Appearance Settings */}
            {activeTab === 'appearance' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Görünüm Ayarları</h2>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Tema
                      </label>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="border-2 border-gray-300 dark:border-gray-600 rounded-lg p-4 cursor-pointer hover:border-blue-500 transition-colors">
                          <div className="w-full h-20 bg-white rounded mb-2"></div>
                          <p className="text-sm text-center text-gray-900 dark:text-white">Açık Tema</p>
                        </div>
                        <div className="border-2 border-gray-300 dark:border-gray-600 rounded-lg p-4 cursor-pointer hover:border-blue-500 transition-colors">
                          <div className="w-full h-20 bg-gray-800 rounded mb-2"></div>
                          <p className="text-sm text-center text-gray-900 dark:text-white">Koyu Tema</p>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Dil
                      </label>
                      <select className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white">
                        <option value="tr">Türkçe</option>
                        <option value="en">English</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex justify-end mt-6">
                    <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2">
                      <Save className="w-4 h-4" />
                      <span>Kaydet</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Status Modal */}
      <AnimatePresence>
        {showStatusModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    {editingStatus ? 'Durum Düzenle' : 'Yeni Durum Ekle'} - {getStatusTypeTitle(currentStatusType)}
                  </h3>
                  
                  <button
                    onClick={() => {
                      setShowStatusModal(false);
                      setEditingStatus(null);
                    }}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Durum Adı *
                    </label>
                    <input
                      type="text"
                      value={editingStatus ? editingStatus.name : newStatus.name}
                      onChange={(e) => {
                        if (editingStatus) {
                          setEditingStatus({ ...editingStatus, name: e.target.value });
                        } else {
                          setNewStatus({ ...newStatus, name: e.target.value });
                        }
                      }}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Durum adını girin"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Renk
                    </label>
                    <div className="flex items-center space-x-3">
                      <input
                        type="color"
                        value={editingStatus ? editingStatus.color : newStatus.color}
                        onChange={(e) => {
                          if (editingStatus) {
                            setEditingStatus({ ...editingStatus, color: e.target.value });
                          } else {
                            setNewStatus({ ...newStatus, color: e.target.value });
                          }
                        }}
                        className="w-12 h-10 border border-gray-300 dark:border-gray-600 rounded cursor-pointer"
                      />
                      <input
                        type="text"
                        value={editingStatus ? editingStatus.color : newStatus.color}
                        onChange={(e) => {
                          if (editingStatus) {
                            setEditingStatus({ ...editingStatus, color: e.target.value });
                          } else {
                            setNewStatus({ ...newStatus, color: e.target.value });
                          }
                        }}
                        className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                        placeholder="#3B82F6"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Açıklama
                    </label>
                    <textarea
                      value={editingStatus ? editingStatus.description : newStatus.description}
                      onChange={(e) => {
                        if (editingStatus) {
                          setEditingStatus({ ...editingStatus, description: e.target.value });
                        } else {
                          setNewStatus({ ...newStatus, description: e.target.value });
                        }
                      }}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                      placeholder="Durum açıklaması"
                    />
                  </div>

                  {/* Color Preview */}
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div 
                      className="w-6 h-6 rounded-full"
                      style={{ backgroundColor: editingStatus ? editingStatus.color : newStatus.color }}
                    />
                    <span className="text-sm text-gray-900 dark:text-white">
                      {editingStatus ? editingStatus.name : newStatus.name || 'Durum Önizlemesi'}
                    </span>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 mt-6">
                  <button
                    onClick={() => {
                      setShowStatusModal(false);
                      setEditingStatus(null);
                    }}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={editingStatus ? handleEditStatus : handleAddStatus}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>{editingStatus ? 'Güncelle' : 'Kaydet'}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Settings;
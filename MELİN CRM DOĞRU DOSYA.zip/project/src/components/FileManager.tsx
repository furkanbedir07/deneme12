import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Upload, 
  Trash2, 
  Download, 
  Eye, 
  Search,
  Filter,
  X,
  Plus,
  Calendar,
  User
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadDate: string;
  uploadedBy: string;
  url: string;
  category: string;
}

interface FileManagerProps {
  onFileSelect?: (file: UploadedFile) => void;
  allowMultiple?: boolean;
  fileType?: 'pdf' | 'image' | 'all';
  showUpload?: boolean;
}

const FileManager: React.FC<FileManagerProps> = ({ 
  onFileSelect, 
  allowMultiple = false, 
  fileType = 'pdf',
  showUpload = true 
}) => {
  const [files, setFiles] = useState<UploadedFile[]>([
    {
      id: '1',
      name: 'Stand_Projesi_Teklifi_2024.pdf',
      size: 2048576,
      type: 'application/pdf',
      uploadDate: '2024-01-15T10:30:00Z',
      uploadedBy: 'Furkan Bedir',
      url: '/uploads/stand_projesi_teklifi.pdf',
      category: 'Teklif'
    },
    {
      id: '2',
      name: 'Hostes_Catering_Teklifi.pdf',
      size: 1536000,
      type: 'application/pdf',
      uploadDate: '2024-01-16T14:20:00Z',
      uploadedBy: 'Ayşe Yılmaz',
      url: '/uploads/hostes_catering_teklifi.pdf',
      category: 'Teklif'
    },
    {
      id: '3',
      name: 'Melin_Dizayn_Sirket_Tanitimi.pdf',
      size: 3072000,
      type: 'application/pdf',
      uploadDate: '2024-01-10T09:15:00Z',
      uploadedBy: 'Mehmet Kaya',
      url: '/uploads/sirket_tanitimi.pdf',
      category: 'Şirket Tanıtımı'
    },
    {
      id: '4',
      name: 'Fuar_Hizmetleri_Katalogu.pdf',
      size: 4096000,
      type: 'application/pdf',
      uploadDate: '2024-01-12T16:45:00Z',
      uploadedBy: 'Furkan Bedir',
      url: '/uploads/fuar_hizmetleri_katalogu.pdf',
      category: 'Katalog'
    },
    {
      id: '5',
      name: 'Stand_Tasarim_Ornekleri.pdf',
      size: 5120000,
      type: 'application/pdf',
      uploadDate: '2024-01-14T11:30:00Z',
      uploadedBy: 'Ayşe Yılmaz',
      url: '/uploads/stand_tasarim_ornekleri.pdf',
      category: 'Örnek'
    }
  ]);

  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadingFiles, setUploadingFiles] = useState<File[]>([]);

  const categories = ['Teklif', 'Şirket Tanıtımı', 'Katalog', 'Örnek', 'Diğer'];

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFileSelect = (file: UploadedFile) => {
    if (allowMultiple) {
      const newSelection = selectedFiles.includes(file.id)
        ? selectedFiles.filter(id => id !== file.id)
        : [...selectedFiles, file.id];
      setSelectedFiles(newSelection);
    } else {
      setSelectedFiles([file.id]);
      if (onFileSelect) {
        onFileSelect(file);
      }
    }
  };

  const handleFileUpload = (uploadedFiles: FileList | null) => {
    if (uploadedFiles) {
      const newFiles = Array.from(uploadedFiles);
      setUploadingFiles(newFiles);
      
      // Simulate file upload
      newFiles.forEach((file, index) => {
        setTimeout(() => {
          const newFile: UploadedFile = {
            id: Date.now().toString() + index,
            name: file.name,
            size: file.size,
            type: file.type,
            uploadDate: new Date().toISOString(),
            uploadedBy: 'Furkan Bedir',
            url: URL.createObjectURL(file),
            category: 'Diğer'
          };
          
          setFiles(prev => [newFile, ...prev]);
          toast.success(`${file.name} başarıyla yüklendi`);
        }, (index + 1) * 500);
      });
      
      setTimeout(() => {
        setUploadingFiles([]);
        setShowUploadModal(false);
      }, newFiles.length * 500 + 500);
    }
  };

  const handleDeleteFile = (fileId: string) => {
    if (window.confirm('Bu dosyayı silmek istediğinizden emin misiniz?')) {
      setFiles(files.filter(file => file.id !== fileId));
      setSelectedFiles(selectedFiles.filter(id => id !== fileId));
      toast.success('Dosya başarıyla silindi');
    }
  };

  const handleDownloadFile = (file: UploadedFile) => {
    // Simulate file download
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Dosya indiriliyor...');
  };

  const filteredFiles = files.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || file.category === selectedCategory;
    const matchesType = fileType === 'all' || 
      (fileType === 'pdf' && file.type === 'application/pdf') ||
      (fileType === 'image' && file.type.startsWith('image/'));
    
    return matchesSearch && matchesCategory && matchesType;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Dosya Yöneticisi
        </h3>
        {showUpload && (
          <button
            onClick={() => setShowUploadModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors text-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Dosya Yükle</span>
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Dosya ara..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white text-sm"
          />
        </div>
        
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white text-sm"
        >
          <option value="all">Tüm Kategoriler</option>
          {categories.map(category => (
            <option key={category} value={category}>{category}</option>
          ))}
        </select>
      </div>

      {/* File List */}
      <div className="max-h-96 overflow-y-auto border border-gray-300 dark:border-gray-600 rounded-lg">
        {filteredFiles.length === 0 ? (
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">Dosya bulunamadı</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {filteredFiles.map((file) => (
              <div
                key={file.id}
                className={`p-4 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors ${
                  selectedFiles.includes(file.id) ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                }`}
                onClick={() => handleFileSelect(file)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="flex-shrink-0">
                      <FileText className="w-8 h-8 text-red-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                        {file.name}
                      </p>
                      <div className="flex items-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
                        <span>{formatFileSize(file.size)}</span>
                        <span className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>{format(new Date(file.uploadDate), 'dd.MM.yyyy', { locale: tr })}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <User className="w-3 h-3" />
                          <span>{file.uploadedBy}</span>
                        </span>
                        <span className="px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded text-xs">
                          {file.category}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownloadFile(file);
                      }}
                      className="p-1 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                      title="İndir"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        window.open(file.url, '_blank');
                      }}
                      className="p-1 text-gray-400 hover:text-green-600 dark:hover:text-green-400 transition-colors"
                      title="Görüntüle"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteFile(file.id);
                      }}
                      className="p-1 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                      title="Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Selected Files Info */}
      {selectedFiles.length > 0 && (
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
          <p className="text-sm text-blue-800 dark:text-blue-200">
            {selectedFiles.length} dosya seçildi
          </p>
        </div>
      )}

      {/* Upload Modal */}
      <AnimatePresence>
        {showUploadModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Dosya Yükle
                  </h3>
                  <button
                    onClick={() => setShowUploadModal(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div 
                  className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center"
                  onDrop={(e) => {
                    e.preventDefault();
                    handleFileUpload(e.dataTransfer.files);
                  }}
                  onDragOver={(e) => e.preventDefault()}
                >
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    Dosyaları buraya sürükleyin veya tıklayın
                  </p>
                  <input
                    type="file"
                    multiple
                    accept={fileType === 'pdf' ? '.pdf' : fileType === 'image' ? 'image/*' : '*'}
                    onChange={(e) => handleFileUpload(e.target.files)}
                    className="hidden"
                    id="file-upload-modal"
                  />
                  <label
                    htmlFor="file-upload-modal"
                    className="cursor-pointer px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                  >
                    Dosya Seç
                  </label>
                </div>

                {uploadingFiles.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      Yükleniyor...
                    </p>
                    {uploadingFiles.map((file, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{ width: '60%' }} />
                        </div>
                        <span className="text-xs text-gray-600 dark:text-gray-400">{file.name}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FileManager;
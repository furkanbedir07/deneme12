import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import LoginForm from './components/LoginForm';
import Dashboard from './components/Dashboard';
import Exhibitions from './components/Exhibitions';
import Companies from './components/Companies';
import Quotations from './components/Quotations';
import EmailTemplates from './components/EmailTemplates';
import Personnel from './components/Personnel';
import Settings from './components/Settings';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <div className="App">
            <Routes>
              <Route path="/login" element={<LoginForm />} />
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <Layout>
                    <Dashboard />
                  </Layout>
                </ProtectedRoute>
              } />
              <Route path="/exhibitions" element={
                <ProtectedRoute>
                  <Layout>
                    <Exhibitions />
                  </Layout>
                </ProtectedRoute>
              } />
              <Route path="/companies" element={
                <ProtectedRoute>
                  <Layout>
                    <Companies />
                  </Layout>
                </ProtectedRoute>
              } />
              <Route path="/quotations" element={
                <ProtectedRoute>
                  <Layout>
                    <Quotations />
                  </Layout>
                </ProtectedRoute>
              } />
              <Route path="/email-templates" element={
                <ProtectedRoute>
                  <Layout>
                    <EmailTemplates />
                  </Layout>
                </ProtectedRoute>
              } />
              <Route path="/personnel" element={
                <ProtectedRoute>
                  <Layout>
                    <Personnel />
                  </Layout>
                </ProtectedRoute>
              } />
              <Route path="/automation" element={
                <ProtectedRoute>
                  <Layout>
                    <div className="text-center p-8">
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Otomasyon</h2>
                      <p className="text-gray-600 dark:text-gray-400">Otomasyon modülü yakında eklenecek.</p>
                    </div>
                  </Layout>
                </ProtectedRoute>
              } />
              <Route path="/settings" element={
                <ProtectedRoute>
                  <Layout>
                    <Settings />
                  </Layout>
                </ProtectedRoute>
              } />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
            </Routes>
            <Toaster position="top-right" />
          </div>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;